# MLP for Pima Indians Dataset Serialize to JSON and HDF5
from keras.models import Sequential
from keras.layers import Dense
from keras.models import model_from_json
import numpy
import os
import sys

def saveInProjectRepo(path):
    ProjectRepo = os.popen('bdvcli --get cluster.project_repo').read().rstrip()
    return ProjectRepo + '/' + path

# load json and create model
json_file = open(saveInProjectRepo('models/demo1/model.json'), 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights(saveInProjectRepo('models/demo1/model.h5'))
print("Loaded model from disk")

# evaluate loaded model on test data
loaded_model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])

b1 = int(sys.argv[1])
b2 = int(sys.argv[2])
numpy.random.seed(7)
dataset = numpy.loadtxt(saveInProjectRepo('data/pima-indians-diabetes.csv'), delimiter=",")
X = dataset[:,b1:b2]
Y = dataset[:,8]

score = loaded_model.evaluate(X, Y, verbose=0)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))
