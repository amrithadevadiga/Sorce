#!/bin/bash
export PATH=$PATH:/opt/anaconda3/bin/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-9.0/lib64:/usr/local/cuda-9.0/extras/CUPTI/lib64
export CUDA_HOME=/usr/local/cuda-9.0/
export PATH=$PATH:/usr/lib64/openmpi-3.1.3/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib64/openmpi-3.1.3/lib/:/opt/anaconda3/pkgs/openssl-1.0.2o-h20670df_0/lib/
