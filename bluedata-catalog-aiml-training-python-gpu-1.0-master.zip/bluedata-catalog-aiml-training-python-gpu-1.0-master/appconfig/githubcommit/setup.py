import setuptools

setuptools.setup(
    name="githubcommit",
    version='0.1.0',
    url="https://github.com/testuser/githubcommit",
    author="TestUser",
    description="Jupyter extension to enable user push notebooks to a git repo",
    packages=setuptools.find_packages(),
    package_data={'githubcommit': ['static/*']},
)
