#!/usr/bin/env python

#
# Copyright (c) 2016, BlueData Software, Inc.
#
# Blueprint script for configuring jupyter notebook

import logging, sys, subprocess, os, json, argparse
from bd_vlib import *

notebook_logger = logging.getLogger("Notebook Configuration")
notebook_logger.setLevel(logging.DEBUG)
hdlr = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
hdlr.setFormatter(formatter)
hdlr.setLevel(logging.DEBUG)
notebook_logger.addHandler(hdlr)

ConfigMeta = BDVLIB_ConfigMetadata()
NODE_GROUP_ID = ConfigMeta.getWithTokens(["node", "nodegroup_id"])
CONFIG_DIR = str(os.environ['CONFIG_BASE_DIR'])
NOTEBOOK_USER= ConfigMeta.getWithTokens(["cluster", "created_by_user_name"])
JUPYTER_NB_CONFIG_FILE_TEMPLATE = "/".join([CONFIG_DIR, "templates" , "jupyter_notebook_config.py"])
JUPYTER_NB_CONFIG_FILE = "/opt/anaconda3/etc/jupyter/jupyter_notebook_config.py"
IPYTHON_CONFIG_FILE_TEMPLATE = "/".join([CONFIG_DIR, "templates", "ipython_config.py"])
JUPYTER_HUB_CONFIG_FILE_TEMPLATE = "/".join([CONFIG_DIR, "templates" , "jupyterhub_config.py"])
R_KERNEL_TEMPLATE = "/".join([CONFIG_DIR, "templates" , "rkernel"])
JULIA_KERNEL_TEMPLATE = "/".join([CONFIG_DIR, "templates", "juliakernel.jl"])
MAGIC_FILE = "/".join([CONFIG_DIR, "templates" , "bluedatamagic.py"])
NOTEBOOK_REPO_DIR = "/".join(["/home", NOTEBOOK_USER, "notebook_repo"])
FQDN = ConfigMeta.getWithTokens(["node", "fqdn"])
LDAPAUTHENTICATOR = "ldapauthenticator.LDAPAuthenticator"
PAMAUTHENTICATOR = "jupyterhub.auth.PAMAuthenticator"
JUPYTERHUB_CONFIG_DIR = "/etc/jupyterhub"
IPYTHON_CONFIG_DIR = "/etc/ipython"
EXTENSIONS_DIR = "/home/{0}/.ipython/extensions".format(NOTEBOOK_USER)
LDAP_AUTH_TYPE = "LDAP"
GIT_PLUGIN_LOG_FILE = "/var/log/bluedata/git-plugin.log"
ATTACHED_CLUSTERS = ConfigMeta.getWithTokens(["attachments", "clusters"])
MAGIC_CONFIG_FILE = "/etc/bluedata/magic-config.json"
GITHUB_PLUGIN_CONFIG_FILE = "/etc/bluedata/githubcommit-config.json"
GITHUB_PLUGIN_PATH = "/opt/bluedata/vagent/guestconfig/appconfig/githubcommit/githubcommit/static"
MIT_KRB5_TEMPLATE = "/".join([CONFIG_DIR, "templates" , "mit-krb5.conf"])




def normalize_cluster_name(name):
    lowercase = name.lower()
    return ''.join(e for e in lowercase if e.isalnum())

def get_attached_cluster_names(attached_cluster_ids):
    if attached_cluster_ids:
        id_to_name = dict()
        for cluster_id in attached_cluster_ids:
            name = ConfigMeta.getWithTokens(["attachments", "clusters", cluster_id, "name"])
            normalized_cluster_name = normalize_cluster_name(name)
            id_to_name[cluster_id] = normalized_cluster_name
        return id_to_name
    else:
        return None

def is_training_cluster_kerberized(clusterid):
    kerberos_token = ConfigMeta.searchForToken("attachments.clusters.{0}.services".format(clusterid), "KERBEROS_CLIENT")
    return kerberos_token != []

def configure_krb5():
    notebook_logger.info("Setup krb5.conf for MIT KDC")
    kdc_host = ConfigMeta.getWithTokens(["tenant", "kdc_host"])
    kdc_realm = ConfigMeta.getWithTokens(["tenant", "kdc_realm"])
    subprocess.check_call(["sed", "-i","s:@@@KDC_REALM@@@:{0}:g".format(kdc_realm), MIT_KRB5_TEMPLATE])
    subprocess.check_call(["sed", "-i","s:@@@KDC_HOST@@@:{0}:g".format(kdc_host), MIT_KRB5_TEMPLATE])
    subprocess.check_call(["cp", "-f", MIT_KRB5_TEMPLATE, "/etc/krb5.conf"])

def get_training_endpoints(attached_cluster_ids):
    names_to_endpoints = dict()
    cluster_ids_to_names = get_attached_cluster_names(attached_cluster_ids)
    for clusterid, name in cluster_ids_to_names.iteritems():
        names_to_endpoints[name] = list()
        exported_service_tokens = ConfigMeta.searchForToken("attachments.clusters.{0}.services".format(clusterid), "AIML/Training")
        if len(exported_service_tokens) == 0:
            notebook_logger.error("Cluster {0} does not have any exported service as AIML/Training".format(name))
            sys.exit(1)
        valid_exported_service_tokens = [token for token in exported_service_tokens if len(token) == 9]
        ml_engine_tokens = ConfigMeta.searchForToken("attachments.clusters.{0}.config_metadata".format(clusterid), "ml_engine")
        if len(ml_engine_tokens) == 0:
            notebook_logger.error("Cluster {0} does not have any expose 'ml_engine' property as config metadata".format(name))
            sys.exit(1)
        ml_engine = ConfigMeta.getWithTokens(ml_engine_tokens[0])
        endpoint_json = dict(endpoints=[], engine=ml_engine, kerberos=False)
        if ml_engine == "spark" and is_training_cluster_kerberized(clusterid):
            configure_krb5()
            endpoint_json['kerberos'] = True
        independent_ng_tokens = [token for token in valid_exported_service_tokens if token[5] == "1"]
        dependent_ng_tokens = [token for token in valid_exported_service_tokens if token[5] != "1"]
        training_endpoint_tokens = dependent_ng_tokens if independent_ng_tokens == [] else independent_ng_tokens
        for token in training_endpoint_tokens:
            service_token = token[:-2]
            service_token.append("endpoints")
            endpoint = ConfigMeta.getWithTokens(service_token)
            endpoint_json["endpoints"].extend(endpoint)
            names_to_endpoints[name] = endpoint_json
    return names_to_endpoints


'''
CREATE MAGIC CONFIG
'''
def create_magic_config():
    notebook_logger.info("Configuring magics")
    subprocess.check_call(["mkdir", JUPYTERHUB_CONFIG_DIR])
    if ATTACHED_CLUSTERS:
        subprocess.check_call(["mkdir", IPYTHON_CONFIG_DIR])
        subprocess.check_call(["cp", IPYTHON_CONFIG_FILE_TEMPLATE, IPYTHON_CONFIG_DIR])
        subprocess.check_call(["sudo", "-u", NOTEBOOK_USER, "mkdir", "-p", EXTENSIONS_DIR])
        with open(MAGIC_CONFIG_FILE, "w") as f:
            training_endpoints = get_training_endpoints(ATTACHED_CLUSTERS)
            json.dump(training_endpoints, f)
        subprocess.check_call(["sudo", "-u", NOTEBOOK_USER, "cp", MAGIC_FILE, EXTENSIONS_DIR])

'''
RECREATE MAGIC CONFIG
'''
def recreate_magic_config():
    subprocess.check_call(["sudo", "-u", NOTEBOOK_USER, "rm", "-f", MAGIC_CONFIG_FILE])
    with open(MAGIC_CONFIG_FILE, "w") as f:
        training_endpoints = get_training_endpoints(ATTACHED_CLUSTERS)
        json.dump(training_endpoints, f)
    subprocess.check_call(["sudo", "-u", NOTEBOOK_USER, "cp", MAGIC_FILE, EXTENSIONS_DIR])


'''
CONFIGURE AUTH FOR JUPYTERHUB
'''
def configure_auth_for_jupyterhub():
    notebook_logger.info("Configure auth for jupyterhub")
    subprocess.check_call(["sed",  "-i", "s/@@@FQDN@@@/{0}/g".format(FQDN), JUPYTER_HUB_CONFIG_FILE_TEMPLATE])
    subprocess.check_call(["sed", "-i", "s/@@@AUTHENTICATOR@@@/{0}/g".format(PAMAUTHENTICATOR), JUPYTER_HUB_CONFIG_FILE_TEMPLATE])
    subprocess.check_call(["sed", "-i", "s/@@@USER@@@/{0}/g".format(NOTEBOOK_USER), JUPYTER_HUB_CONFIG_FILE_TEMPLATE])
    subprocess.check_call(["cp", JUPYTER_HUB_CONFIG_FILE_TEMPLATE, JUPYTERHUB_CONFIG_DIR])


'''
CONFIGURE JULIA AND R KERNELS
'''
#subprocess.check_call(["sudo", "-u", NOTEBOOK_USER, "/opt/anaconda3/bin/julia", JULIA_KERNEL_TEMPLATE])

'''
CONFIGURE SOURCE CONTROL FOR NOTEBOOKS
'''
def configure_source_control():
    notebook_logger.info("Fetch Source Control Data")
    try:
        source_control_type = ConfigMeta.getWithTokens(["tenant", "source_control_type"])
    except:
        source_control_type = None
    subprocess.check_call(["/opt/anaconda3/bin/jupyter", "nbextension", "enable", "--py", "--sys-prefix", "widgetsnbextension"])
    if source_control_type is not None:
        notebook_logger.info("Configure Source Control")
        subprocess.check_call(["mkdir", "-p",  NOTEBOOK_REPO_DIR])
        subprocess.check_call(["chmod", "-R", "777",  NOTEBOOK_REPO_DIR])
        GITHUB_REPO_URL = ConfigMeta.getWithTokens(["tenant", "github_repo_url"]).strip()
        GITHUB_BRANCH = ConfigMeta.getWithTokens(["tenant", "github_branch"]).strip()
        GITHUB_ACCESS_TOKEN = ConfigMeta.getWithTokens(["tenant", "github_access_token"]).strip()
        GITHUB_USER_NAME = ConfigMeta.getWithTokens(["tenant", "github_user_name"]).strip()
        GITHUB_USER_EMAIL = ConfigMeta.getWithTokens(["tenant", "github_user_email"]).strip()
        TOKENIZED_REPO_URL = GITHUB_REPO_URL.replace("github.com", "@".join([GITHUB_ACCESS_TOKEN, "github.com"]))
        PROXYPORT = ConfigMeta.getWithTokens(["platform", "proxyport"]).strip()
        PROXYHOSTNAME = ConfigMeta.getWithTokens(["platform", "proxyhostname"]).strip()
        PROXYPROTOCOL = ConfigMeta.getWithTokens(["platform", "proxyprotocol"]).strip()
        try:
            NOTEBOOK_WORKING_DIR = ConfigMeta.getWithTokens(["tenant", "working_dir"])
        except:
            NOTEBOOK_WORKING_DIR = ""
            notebook_logger.warn("Working directory is not set in Source Control - Github configuration.")

        githubcommit_config = {}
        githubcommit_config['github_repo_url'] = TOKENIZED_REPO_URL
        githubcommit_config['github_branch'] = GITHUB_BRANCH
        githubcommit_config['github_user_name'] = GITHUB_USER_NAME
        githubcommit_config['github_user_email'] = GITHUB_USER_EMAIL
        githubcommit_config['git_repo_root'] = NOTEBOOK_REPO_DIR
        githubcommit_config['git_plugin_log_file'] = GIT_PLUGIN_LOG_FILE
        githubcommit_config['proxyport'] = PROXYPORT
        githubcommit_config['proxyhostname'] = PROXYHOSTNAME
        githubcommit_config['proxyprotocol'] = PROXYPROTOCOL

        if NOTEBOOK_WORKING_DIR == "":
            git_working_dir = NOTEBOOK_REPO_DIR
        else:
            git_working_dir = "/".join([NOTEBOOK_REPO_DIR, NOTEBOOK_WORKING_DIR])
        githubcommit_config['git_working_dir'] = NOTEBOOK_WORKING_DIR
        with open(GITHUB_PLUGIN_CONFIG_FILE, "w") as f:
            json.dump(githubcommit_config, f)
        with open(JUPYTER_NB_CONFIG_FILE_TEMPLATE, 'a') as n:
            n.write("c.NotebookApp.notebook_dir = '{0}'".format(git_working_dir))

        if (PROXYPROTOCOL and PROXYHOSTNAME):
            if PROXYPORT:
                os.environ["http_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\""
                os.environ["https_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\""
                notebook_logger.debug("http_proxy env is set to - " + "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\"")
            else:
                os.environ["http_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME
                os.environ["https_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME
                notebook_logger.debug("http_proxy env set to - " + "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME)
        subprocess.check_call(["touch", GIT_PLUGIN_LOG_FILE])
        subprocess.check_call(["chmod", "777", GIT_PLUGIN_LOG_FILE])
        try:
            subprocess.check_call(["git", "clone", TOKENIZED_REPO_URL, NOTEBOOK_REPO_DIR])
        except:
            notebook_logger.error("Unable to connect Github. Please verify Github configurations or proxy URL")
            raise Exception("Unable to connect Github.")

        os.chdir(NOTEBOOK_REPO_DIR)
        if NOTEBOOK_WORKING_DIR != "" and (not os.path.exists(git_working_dir)):
            notebook_logger.error("Invalid Github Working Directory mentioned in Source Control - Github configuration.")
            raise Exception('Invalid Github Working Directory')
        subprocess.check_call(["git", "checkout", GITHUB_BRANCH])
        subprocess.check_call(["chown", "-R", ":".join([NOTEBOOK_USER, "shadow"]), NOTEBOOK_REPO_DIR])
        os.chdir("/".join([CONFIG_DIR, "githubcommit"]))
        subprocess.check_call(["/opt/anaconda3/bin/python", "setup.py", "develop"])
        subprocess.check_call(["git", "config", "--system",  "user.name", GITHUB_USER_NAME])
        subprocess.check_call(["git", "config", "--system",  "user.email", GITHUB_USER_EMAIL])
        subprocess.check_call(["cp", JUPYTER_NB_CONFIG_FILE_TEMPLATE, JUPYTER_NB_CONFIG_FILE])
        subprocess.check_call(["/opt/anaconda3/bin/jupyter-serverextension", "enable", "--py", "githubcommit", "--sys-prefix"])
        subprocess.check_call(["/opt/anaconda3/bin/jupyter-nbextension", "install", GITHUB_PLUGIN_PATH, "--symlink"])
        subprocess.check_call(["/opt/anaconda3/bin/jupyter-nbextension", "enable", "static/main", "--sys-prefix"])

def restart_notebook_server():
    subprocess.check_call(["systemctl", "stop",  "notebook-hub"])
    subprocess.check_call(["systemctl", "start",  "notebook-hub"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Notebook Configuration Parser")
    parser.add_argument("--reattach", action="store_true", help="Configure Notebook for reattaching")
    args = parser.parse_args()
    if args.reattach:
        recreate_magic_config()
        restart_notebook_server()
    else:
        create_magic_config()
        configure_auth_for_jupyterhub()
        configure_source_control()

