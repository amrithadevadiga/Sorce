import json, requests, time
from random import shuffle
from tabulate import tabulate
from IPython.core.magic_arguments import (argument, magic_arguments, parse_argstring)
from livy.models import SessionKind, StatementKind, SessionState, StatementState
from livy.client import LivyClient
from livy.session import LivySession, polling_intervals


class TrainSpark:

    def __init__(self, livy_url, clustername):
        self.livy_url = livy_url
        self.clustername = clustername
        self.livy_client = LivyClient(self.livy_url)
        self.livy_sessions_cache = dict()
        self.livyApiHeader = {'Content-Type': 'application/json'}
        self.livyActiveSessionStates = set(["idle"])

    def __get_active_session__(self):

        all_sessions = self.livy_client.list_sessions()
        active_sessions = [session.session_id for session in all_sessions if session.state == SessionState.IDLE and
                           session.kind == SessionKind.SHARED]
        if active_sessions:
            session_id = active_sessions[0]
        else:
            session_id  = self.livy_client.create_session(kind=SessionKind.SHARED).session_id

            def state(session_id):
                session = self.livy_client.get_session(session_id)
                if session is None:
                    raise ValueError("session not found - it may have been shut down")
                return session.state

            intervals = polling_intervals([0.1, 0.2, 0.3, 0.5], 1.0)
            not_ready = {SessionState.NOT_STARTED, SessionState.STARTING}
            while state(session_id) in not_ready:
                time.sleep(next(intervals))

        return session_id

    def __run_code(self, session_id, code, codetype):
        statement = self.livy_client.create_statement(session_id, code, codetype)

        intervals = polling_intervals([0.1, 0.2, 0.3, 0.5], 1.0)

        def waiting_for_output(statement):
            not_finished = statement.state in {
                StatementState.WAITING,
                StatementState.RUNNING,
            }
            available = statement.state == StatementState.AVAILABLE
            return not_finished or (available and statement.output is None)

        while waiting_for_output(statement):
            time.sleep(next(intervals))
            statement = self.livy_client.get_statement(
                statement.session_id, statement.statement_id
            )

        if statement.output is None:
            raise RuntimeError("statement had no output")

        print(statement.output.text)
        statement.output.raise_for_status()
        return statement.output

    @magic_arguments()
    @argument('--scala', help='Exceute Scala code.', action="store_true")
    @argument('--pyspark', help='Exceute Python code.', action="store_true")
    @argument('--sparkr', help='Exceute R code.', action="store_true")
    @argument('--sql', help='Exceute SQL.', action="store_true")
    def train_spark(self, line, code):
        args = parse_argstring(self.train_spark, line)
        session_id = self.__get_active_session__()
        if args.scala:
            self.__run_code(session_id, code, StatementKind.SPARK)
        elif args.pyspark:
            self.__run_code(session_id, code, StatementKind.PYSPARK)
        elif args.sparkr:
            self.__run_code(session_id, code, StatementKind.SPARKR)
        elif args.sql:
            self.__run_code(session_id, code, StatementKind.SQL)


class TrainPython:

    def __init__(self, clustername, endpoints):
        self.clustername = clustername
        self.endpoints = endpoints
        self.history_url = None

    def train_python(self, line, code):
        shuffle(self.endpoints)
        url = self.endpoints[0]
        d = {
            "model_json" : [{"x": "1.88989", "y": "676.8989"}],
            "train_cmd" : "",
            "training_code" : code
        }
        headers = {'content-type': 'application/json'}
        payload = json.dumps(d)
        json_response = requests.request("POST", url, data=payload, headers=headers).json()
        self.history_url = json_response['request_url']
        print("History URL: {0}".format(self.history_url))

    def logs(self, line = None, code = None):
        if self.history_url is not None:
            history_response = requests.request("GET", self.history_url).json()[0]
            status = history_response['status']
            log_url = history_response['log_url']
            print("Job Status: {0}".format(status))
            logs_json = requests.request("GET", log_url).json()
            if logs_json['logs']:
                print(logs_json['logs'])
        else:
            print("No logs to show for cluster {0} at this time".format(self.clustername))


class AttachmentsMagic:

    def __init__(self, attachments):
        self.attachments_map = attachments

    def attachments(self, line):
        table = []
        for clustername, cluster_details in self.attachments_map.items():
            row = [clustername, cluster_details["engine"]]
            table.append(row)
        print(tabulate(table, headers=['Training Cluster', 'ML Engine']))


def load_ipython_extension(ipython):
    # The `ipython` argument is the currently active `InteractiveShell`
    # instance, which can be used in any way. This allows you to register
    # new magics or aliases, for example.
    MAGIC_CONFIG_FILE = "/etc/bluedata/magic-config.json"
    with open(MAGIC_CONFIG_FILE, "r") as f:
        names_to_endpoints = json.load(f)

    attachmentmagicobj = AttachmentsMagic(names_to_endpoints)
    ipython.register_magic_function(attachmentmagicobj.attachments, "line")
    for clustername, cluster_details in names_to_endpoints.items():
        endpoints = cluster_details["endpoints"]
        if cluster_details["engine"] == "spark":
            livy_url = endpoints[0]
            trainsparkobj = TrainSpark(livy_url, clustername)
            ipython.register_magic_function(trainsparkobj.train_spark, "line_cell", clustername)
        elif cluster_details["engine"] == "python":
            trainpythonobj = TrainPython(clustername, endpoints)
            ipython.register_magic_function(trainpythonobj.train_python, "line_cell", clustername)
            ipython.register_magic_function(trainpythonobj.logs, "line_cell", "logs")
