using Pkg
ENV["JUPYTER"] = "/opt/anaconda3/bin/jupyter"
Pkg.add("IJulia")