## Python Datascience image with GPU support
# CentOS 7 catalog entry.
# Install scipy

Fixes:
- CE-341 AI-ML: Creating a Notebook cluster attached to a Training cluster is failing.
