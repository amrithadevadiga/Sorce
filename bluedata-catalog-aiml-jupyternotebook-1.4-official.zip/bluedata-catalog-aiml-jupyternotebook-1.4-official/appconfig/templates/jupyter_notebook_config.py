c.NotebookApp.disable_check_xsrf = True
c.NotebookApp.nbserver_extensions = {
    'githubcommit': True,
}
