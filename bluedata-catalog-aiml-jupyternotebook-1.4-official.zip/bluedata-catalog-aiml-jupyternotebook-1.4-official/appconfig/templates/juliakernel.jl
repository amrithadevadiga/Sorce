using Pkg
ENV["JUPYTER"] = "/opt/miniconda/bin/jupyter"
Pkg.add("IJulia")