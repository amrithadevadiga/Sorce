from notebook.utils import url_path_join as ujoin
from notebook.base.handlers import IPythonHandler
import os, json, git, urllib, logging, sys
from git import Repo, GitCommandError

GITHUB_PLUGIN_CONFIG_FILE = "/etc/bluedata/githubcommit-config.json"
with open(GITHUB_PLUGIN_CONFIG_FILE) as f:
    git_config = json.load(f)
plugin_logger = logging.getLogger("Git Plugin")
plugin_logger.setLevel(logging.DEBUG)
hdlr = logging.FileHandler(git_config['git_plugin_log_file'])
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
hdlr.setFormatter(formatter)
hdlr.setLevel(logging.DEBUG)
plugin_logger.addHandler(hdlr)

class GitCommitHandler(IPythonHandler):

    def error_and_return(self, dirname, reason):

        # send error
        self.send_error(500, reason=reason)

        # return to directory
        os.chdir(dirname)

    def put(self):

        plugin_logger.info("GitHubCommit PUT called")
        # git parameters from environment variables
        # expand variables since Docker's will pass VAR=$VAL as $VAL without expansion

        git_repo_root = git_config['git_repo_root']
        git_working_dir = git_config['git_working_dir']
        git_branch = git_config['github_branch']
        git_remote = "origin"
        PROXYPORT = git_config['proxyport']
        PROXYHOSTNAME = git_config['proxyhostname']
        PROXYPROTOCOL = git_config['proxyprotocol']
        if (PROXYPROTOCOL and PROXYHOSTNAME):
            if PROXYPORT:
                os.environ["http_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\""
                os.environ["https_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\""
                plugin_logger.debug("http_proxy env is set to - " + "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME + ":" + PROXYPORT + "\"")
            else:
                os.environ["http_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME
                os.environ["https_proxy"] = "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME
                plugin_logger.debug("http_proxy env set to - " + "\"" + PROXYPROTOCOL + "://" + PROXYHOSTNAME)

        # obtain filename and msg for commit
        data = json.loads(self.request.body.decode('utf-8'))
        plugin_logger.info(data)
        filename = data['filename']
        msg = data['msg']

        # get current directory (to return later)
        cwd = os.getcwd()

        # select branch within repo
        try:
            os.chdir(git_repo_root)
            #dir_repo = check_output(['git','rev-parse','--show-toplevel']).strip()
            repo = Repo(git_repo_root)
        except GitCommandError as e:
            self.error_and_return(cwd, "Could not checkout repo: {}".format(git_repo_root))
            return

        # checkout the branch
        try:
            plugin_logger.info(repo.git.checkout(git_branch))
        except GitCommandError as g:
            self.error_and_return(cwd, "Could not checkout branch: {}".format(git_branch))
            plugin_logger.error(g)
            return


        # commit current notebook
        # client will sent pathname containing git directory; append to git directory's parent
        try:
            fqfilename = "".join([git_working_dir, filename])
            plugin_logger.info("add file: {}".format(fqfilename))
            plugin_logger.info(repo.git.add(fqfilename))
            plugin_logger.info(repo.git.commit(a=True, m="{}\n\nUpdated {}".format(msg, filename)))
        except GitCommandError as e:
            plugin_logger.error(e)
            self.error_and_return(cwd, "Could not commit changes to notebook: {}".format("/".join([git_working_dir, filename])))
            return

        # create or switch to remote
        try:
            remote = repo.remote(git_remote)
        except GitCommandError as g:
            self.error_and_return(cwd, "Could not checkout branch: {}".format(git_branch))
            return


        # push changes
        try:
            pushed = remote.push(git_branch)
            assert len(pushed)>0
            assert pushed[0].flags in [git.remote.PushInfo.UP_TO_DATE, git.remote.PushInfo.FAST_FORWARD, git.remote.PushInfo.NEW_HEAD, git.remote.PushInfo.NEW_TAG]
        except GitCommandError as e:
            plugin_logger.error(e)
            self.error_and_return(cwd, "Could not push to remote {}".format(git_remote))
            return
        except AssertionError as e:
            self.error_and_return(cwd, "Could not push to remote {}: {}".format(git_remote, pushed[0].summary))
            return

        # return to directory
        os.chdir(cwd)

        # close connection
        self.write({'status': 200, 'statusText': 'Success!  Changes to {} captured on branch {}'.format(filename, git_branch)})


def setup_handlers(nbapp):
    plugin_logger.info("handler setup")
    plugin_logger.info("handler setup. {}".format(nbapp.settings))
    route_pattern = ujoin(nbapp.settings['base_url'], '/git/commit')
    plugin_logger.info("handler setup. {}".format(route_pattern))
    nbapp.add_handlers('.*', [(route_pattern, GitCommitHandler)])
    plugin_logger.info("handler setup. handler added")
