Jupyter Notebook for AI/ML

Features:

- AD/LDAP Integration for logic
- Github support to check in notebooks.
- Python and R kernels pre-configured


EPIC versions this bin file is intended for:

- 4.0 and beyond

Fixes:
- CE-288 notebook: better off throwing the error at cluster creation time if there is no working directory in github
- CE-254 notebook: Support a proxy server for github access in notebook
