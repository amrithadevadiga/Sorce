#!/bin/env python

#
# Copyright (c) 2016, BlueData Software, Inc.
#
# Blueprint tuning script for Pivotal clusters
import json,os,logging,sys
from bd_vlib import *


configure_blueprint_logger = logging.getLogger("bluedata_adv_tuning")
configure_blueprint_logger.setLevel(logging.DEBUG)
hdlr = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
hdlr.setFormatter(formatter)
hdlr.setLevel(logging.DEBUG)
configure_blueprint_logger.addHandler(hdlr)

ConfigMetaA = BDVLIB_ConfigMetadata()
ALL_HOSTS = ConfigMetaA.getClusterHostsFQDN()
NODE_GROUP_ID = ConfigMetaA.getWithTokens(["node", "nodegroup_id"])
DISTRO_ID = ConfigMetaA.getWithTokens(["node", "distro_id"])
DTAP_JAR = "/opt/bluedata/bluedata-dtap.jar"

FQDN = ConfigMetaA.getWithTokens(["node", "fqdn"])
IS_KERBEROS_ENABLED = ConfigMetaA.getWithTokens(["cluster", "config_choice_selections", NODE_GROUP_ID, "kerberos"])
base_dir = os.environ["CONFIG_BASE_DIR"]
ConfigMeta = BDVLIB_ConfigMetadata(metaFile="/etc/bluedata/.priv_configmeta.json")

def get_security_config(krb_env_data,krb5_conf_data):

    krb_env_config = {
        'realm' : ConfigMeta.getWithTokens(["tenant", "kdc_realm"]),
        'kdc_type' : 'active-directory' if 'Active Directory' in ConfigMeta.getWithTokens(["tenant", "kdc_type"]) else 'mit-kdc',
        'kdc_hosts' : ConfigMeta.getWithTokens(["tenant", "kdc_host"]),
        'admin_server_host' : ConfigMeta.getWithTokens(["tenant", "kdc_host"]),
        "manage_identities": "true"
    }
    DefinedTenantKeys = ConfigMeta.getWithTokens(["tenant"])
    if "krb_enc_types" in DefinedTenantKeys:
        configured_enc_types = ConfigMeta.getWithTokens(["tenant", "krb_enc_types"])
        configured_enc_types = " ".join(configured_enc_types)
        if configured_enc_types != '':
            krb_env_config['encryption_types'] = configured_enc_types

    if krb_env_config['kdc_type'] is 'active-directory':
        krb_env_config['ldap_url'] = "ldaps://"+ConfigMeta.getWithTokens(["tenant", "kdc_host"])
        krb_env_config['container_dn'] = ConfigMeta.getWithTokens(["tenant", "kdc_ad_suffix"])

    krb_env_data["kerberos-env"].update(krb_env_config)
    configure_blueprint_logger.info("Setting Kerberos Env config to {0}".format(krb_env_config))

    krb5_config = {
        "domains" : ConfigMeta.getWithTokens(["tenant", "kdc_realm"]),
        "manage_krb5_conf" : "true" if 'Active Directory' in ConfigMeta.getWithTokens(["tenant", "kdc_type"]) else "false"
    }
    krb5_conf_data["krb5-conf"].update(krb5_config)
    configure_blueprint_logger.info("Setting krb5 config to {0}".format(krb5_config))
    return [krb_env_data,krb5_conf_data]

def add_krb_components_to_blueprint(blueprint_data):

    host_groups = blueprint_data['host_groups']
    for host_group in host_groups:
        if host_group['name'] != 'controller':
            host_group['components'].append({"name": "KERBEROS_CLIENT"})
    return host_groups

def generate_security_configuration(filePath):
    jsonFile = open(filePath, "r")  # Open the JSON file for reading
    data = json.load(jsonFile)  # Read the JSON into the buffer
    jsonFile.close()  # Close the JSON file
    if IS_KERBEROS_ENABLED:
        krb_env_template = open(base_dir + '/templates/kerberos-env.template').read()
        krb5_conf_template = open(base_dir + '/templates/krb5-conf.template').read()
        krb_env_data = json.loads(krb_env_template)
        krb5_conf_data = json.loads(krb5_conf_template)
        data["configurations"] += get_security_config(krb_env_data, krb5_conf_data)
        data['Blueprints']['security']= {"type":"KERBEROS"}
        data.update({'host_groups': add_krb_components_to_blueprint(data)})
        for item in  data["host_groups"]:
            if item["name"]=="controller":
                item.update({"cardinality":"1","configurations":[]})
            else:
                item.update({"cardinality":"1+","configurations":[]})
        jsonFile = open(filePath, "w+")
        jsonFile.write(json.dumps(data))
        jsonFile.close()
    else:
        data['Blueprints']['security'] = dict(type="NONE")
        for item in  data["host_groups"]:
            if item["name"]=="controller":
                item.update({"cardinality":"1","configurations":[]})
            else:
                item.update({"cardinality":"1+","configurations":[]})
        jsonFile = open(filePath, "w+")
        jsonFile.write(json.dumps(data))
        jsonFile.close()

def main():
    generate_security_configuration(base_dir+"/blueprint.json")
if __name__ == '__main__':
    main()
