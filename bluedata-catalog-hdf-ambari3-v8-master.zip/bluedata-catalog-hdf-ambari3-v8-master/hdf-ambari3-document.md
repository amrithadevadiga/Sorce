# Overview

In this image, the user can access amabri 2.7.1.0 with NIFI, NIFI-REGISTRY, STORM, STREAM LINE ANALYTICS, Kafka, Schema Registry and GRAFANA.

## What is {name}?

Hortonworks DataFlow (HDF) is a scalable, real-time streaming analytics platform that ingests, curates and analyzes data for key insights and immediate actionable intelligence. DataFlow addresses the key challenges enterprises face with data-in-motion—real-time stream processing of data at high volume and high scale, data provenance and ingestion from IoT devices, edge applications and streaming sources.

For more details about HDF, refer to this link:
https://hortonworks.com/products/data-platforms/hdf/ 

# Details:
## Application Image Details:

### AppName: 
{name}
### DistroId:
{distroid}
### Version: 
{version}

### Cluster Type: 
HDF
### Software Included: 
HDF - 3.3.0.0-165, 
AMBARI – 2.7.1.0
Python 2.7.5 (64-bit), 
ZooKeeper - 3.4.6
NIFI - 1.8.0.3.3,
NIFI REGISTRY - 0.3.0.3.3,
Ambari Metrics - 0.1.0,
KAFKA – 2.0.0.3.3,
STREAM LINE ANALYTICS – 0.6.0,
Schema Registry	- 0.5.4,
STORM - 1.2.1.3.3

### Amabri GUI Access:

Go to the HDF cluster in BlueData EPIC GUI and click on Amabri link   
Login with admin/admin

### NIFI GUI Access:

Go to the HDF cluster in BlueData EPIC GUI and click on NIFI link

### NIFI REGISTRY GUI Access:

Go to the HDF cluster in BlueData EPIC GUI and click on NIFI REGISTRY link

### STORM GUI Access:

Go to the HDF cluster in BlueData EPIC GUI and click on STORM link

### Grafana GUI Access:

Go to the HDF cluster in BlueData EPIC GUI and click on Grafana link

NIFI_HOME: /usr/hdf/3.3.0.0-165/nifi/bin/
NIFI-REGISTRY_HOME: /usr/hdf/3.3.0.0-165/nifi-registry/bin/
STORM_HOME: /usr/hdf/3.3.0.0-165/storm/bin/
STREAMLINE-ANALYTICS_HOME: /usr/hdf/3.3.0.0-165/streamline/bin/
Schema Registry	- /usr/hdf/3.3.0.0-165/registry/bin/
KAFKA_HOME: /usr/hdf/3.3.0.0-165/kafka/bin/

### OS: 
Centos7.4 Works with both Bluedata Centos and RHEL hosts

## Testcases:

[HDF_testcases](https://github.com/bluedatainc/solutions/blob/master/AppImage_Testcases/HDF330/2.4/hdf330-smoketests.pdf)

## Prerequisites:

The user should have prior experience working with the App.
Prior Knowledge working with EPIC.
Basic understanding of docker, Nifi, Kafka for running testcases.

## Release notes:

None


