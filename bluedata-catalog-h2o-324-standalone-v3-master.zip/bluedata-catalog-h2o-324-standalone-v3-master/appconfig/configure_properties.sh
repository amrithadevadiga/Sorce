#!/bin/sh
set -o pipefail
SELF=$(readlink -nf $0)
export CONFIG_BASE_DIR=$(dirname ${SELF})
source ${CONFIG_BASE_DIR}/logging.sh
source ${CONFIG_BASE_DIR}/utils.sh
source ${CONFIG_BASE_DIR}/macros.sh
CLUSTER_NAME="$(invoke_bdvcli --get cluster.name)"
FQDN="$(invoke_bdvcli --get node.fqdn)"
ROLE="$(invoke_bdvcli --get node.role_id)"
#
# H2O configuration create flatfile
# H2O_master H2O_slave

rm -f /usr/lib/h2o/latest/conf/flatfile 

H2O_MASTER=$(invoke_bdvcli --get services.h2o.1.H2O_Master.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IP_H2O_MASTER=$(host ${H2O_MASTER} | awk '{print $4}')
echo "$IP_H2O_MASTER:54321" > /usr/lib/h2o/latest/conf/flatfile 


H2O_LIST=$(invoke_bdvcli --get services.h2o.1.H2O_Slave.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a H2O_LIST <<< "$H2O_LIST"
COUNT_H2O_LIST=`echo ${#H2O_LIST[@]}`

for ((i=0;i < $COUNT_H2O_LIST;i++)){
	IP=$(host ${H2O_LIST[$i]} | awk '{print $4}')
	echo "$IP:54321" >> /usr/lib/h2o/latest/conf/flatfile 
}


#
# H2O change the number of vcore and memrory and name of the cluster
#

PRIMARY_NODEGROUP=1
DISTRO=$(invoke_bdvcli --get node.distro_id)
CORES=$(invoke_bdvcli --get distros.${DISTRO}.1.roles.${ROLE}.flavor.cores)
RAM=$(invoke_bdvcli --get distros.${DISTRO}.1.roles.${ROLE}.flavor.memory)
RAMGB=`expr $RAM / 1024 / 3 \* 2`

sed --i s/@@@@H2O_MAX_CORES@@@@/$CORES/g /lib/systemd/system/h2o.service
sed --i s/@@@@H2O_MAX_RAM@@@@/$RAMGB/g /lib/systemd/system/h2o.service
sed --i s/@@@@H2O_CLUSTER_NAME@@@@/$CLUSTER_NAME/g /lib/systemd/system/h2o.service
