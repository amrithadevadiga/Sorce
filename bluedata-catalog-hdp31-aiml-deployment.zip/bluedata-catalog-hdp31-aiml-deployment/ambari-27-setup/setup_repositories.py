#!/bin/env python
#
# Copyright (c) 2019, BlueData Software, Inc.
#
# Setup Local repositories for HDP

from bd_vlib import *
import logging, sys, os, subprocess
from optparse import OptionParser

setup_repo_logger = logging.getLogger('setup_repo_logger')
setup_repo_logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
setup_repo_logger.addHandler(handler)

ConfigMeta = BDVLIB_ConfigMetadata()

parser = OptionParser()
parser.add_option('', '--hdprepourl', dest='HDP_REPO_URL')
parser.add_option('', '--hdputilsrepourl', dest='HDPUTILS_REPO_URL')
parser.add_option('', '--hdpgplrepourl',dest='HDPGPL_REPO_URL')
parser.add_option('', '--centosbaseurl', dest='CENTOSBASE_URL')
parser.add_option('', '--centosupdatesurl', dest='CENTOSUPDATES_URL')
parser.add_option('', '--centosextrasurl', dest='CENTOSEXTRAS_URL')
parser.add_option('', '--centosplusurl', dest='CENTOSPLUS_URL')
parser.add_option('', '--epelurl', dest='EPEL_URL')
parser.add_option('', '--role', dest='ROLE')
(options, args) = parser.parse_args()

setup_repo_logger.info("HDP repo url option: " + options.HDP_REPO_URL)
setup_repo_logger.info("HDPUTILS repo url option: " + options.HDPUTILS_REPO_URL)
setup_repo_logger.info("HDPGPL repo url option: " + options.HDPGPL_REPO_URL)
setup_repo_logger.info("Centos base url option: " + options.CENTOSBASE_URL)
setup_repo_logger.info("Centos Updates url option: " + options.CENTOSUPDATES_URL)
setup_repo_logger.info("Centos Extras url option: " + options.CENTOSEXTRAS_URL)
setup_repo_logger.info("Centos Plus url option: " + options.CENTOSPLUS_URL)
setup_repo_logger.info("EPEL url option: " + options.EPEL_URL)
setup_repo_logger.info("role: " + options.ROLE)
NODE_GROUP_ID = ConfigMeta.getWithTokens(["node", "nodegroup_id"])
TEMPLATES_DIR = os.environ['TEMPLATES_DIR']
VDF_FILE_NAME= os.environ['VDF_FILE_NAME']
VDF_FILE_PATH = "/".join([TEMPLATES_DIR, VDF_FILE_NAME])
HDP_REPO_TEMPLATE_PATH = "/".join([TEMPLATES_DIR, "hdp.local.repo.template"])
CENTOS_REPO_TEMPLATE_PATH = "/".join([TEMPLATES_DIR, "centos-base.repo.template"])
EPEL_REPO_TEMPLATE_PATH = "/".join([TEMPLATES_DIR, "epel.repo.template"])

if options.ROLE == "master":
    with open(VDF_FILE_PATH) as VDF:
        vdfFileContent = VDF.read()

    with open(VDF_FILE_PATH, "w") as VDF:
        r = vdfFileContent.replace('@@@HDPBASEURL@@@', options.HDP_REPO_URL)
        s = r.replace('@@@HDPGPLBASEURL@@@', options.HDPGPL_REPO_URL)
        t = s.replace('@@@HDPUTILSBASEURL@@@', options.HDPUTILS_REPO_URL)
        VDF.write(t)

with open(HDP_REPO_TEMPLATE_PATH) as HDP_REPO:
    hdprepoFileContent = HDP_REPO.read()

with open(HDP_REPO_TEMPLATE_PATH, "w") as HDP_REPO:
    u = hdprepoFileContent.replace('@@@HDPBASEURL@@@', options.HDP_REPO_URL)
    v = u.replace('@@@HDPUTILSBASEURL@@@', options.HDPUTILS_REPO_URL)
    HDP_REPO.write(v)

with open(CENTOS_REPO_TEMPLATE_PATH) as CENTOS_REPO:
    centosrepoFileContent = CENTOS_REPO.read()

with open(CENTOS_REPO_TEMPLATE_PATH, "w") as CENTOS_REPO:
    w = centosrepoFileContent.replace('@@@CENTOSBASEURL@@@', options.CENTOSBASE_URL)
    x = w.replace('@@@CENTOSUPDATESURL@@@', options.CENTOSUPDATES_URL)
    y = x.replace('@@@CENTOSEXTRASURL@@@', options.CENTOSEXTRAS_URL)
    z = y.replace('@@@CENTOSPLUSURL@@@', options.CENTOSPLUS_URL)
    CENTOS_REPO.write(z)

with open(EPEL_REPO_TEMPLATE_PATH) as EPEL_REPO:
    epelrepoFileContent = EPEL_REPO.read()

with open(EPEL_REPO_TEMPLATE_PATH, "w") as EPEL_REPO:
    w = epelrepoFileContent.replace('@@@EPELBASEURL@@@', options.EPEL_URL)
    EPEL_REPO.write(w)

subprocess.check_call(["cp", "-f", HDP_REPO_TEMPLATE_PATH, "/etc/yum.repos.d/hdp.repo"])
subprocess.check_call(["cp", "-f", CENTOS_REPO_TEMPLATE_PATH, "/etc/yum.repos.d/CentOS-Base.repo"])
subprocess.check_call(["cp", "-f", EPEL_REPO_TEMPLATE_PATH, "/etc/yum.repos.d/epel.repo"])


