#!/bin/env python

#
# Copyright (c) 2016, BlueData Software, Inc.
#
# Blueprint tuning script for Pivotal clusters
import json
from bd_vlib import *
from service_configs import *


configure_blueprint_logger = logging.getLogger("bluedata_adv_tuning")
configure_blueprint_logger.setLevel(logging.DEBUG)
hdlr = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
hdlr.setFormatter(formatter)
hdlr.setLevel(logging.DEBUG)
configure_blueprint_logger.addHandler(hdlr)

ConfigMeta = BDVLIB_ConfigMetadata()
ALL_HOSTS = ConfigMeta.getLocalGroupHosts()
NODE_GROUP_ID = ConfigMeta.getWithTokens(["node", "nodegroup_id"])
DISTRO_ID = ConfigMeta.getWithTokens(["node", "distro_id"])
DTAP_JAR = "/opt/bluedata/bluedata-dtap.jar"
HADOOP_DATA_DIR = "/data"
HADOOP_DATA_SHUFFLE_DIR = "/shuffle"
FQDN = ConfigMeta.getWithTokens(["node", "fqdn"])
IS_HA = ConfigMeta.getWithTokens(["cluster", "config_choice_selections",NODE_GROUP_ID, "all_ha"])
IS_KERBEROS_ENABLED = ConfigMeta.getWithTokens(["cluster", "config_choice_selections", NODE_GROUP_ID, "kerberos"])
#APPS_ENABLED = ConfigMeta.getWithTokens(["cluster", "config_choice_selections", NODE_GROUP_ID, "apps"])
NODEGROUPS = [NODE_GROUP_ID]
ROLES = [ role for ng in NODEGROUPS   for role in ConfigMeta.getWithTokens(["nodegroups", ng, "roles"])]
HDP_STACK_VERSION = ConfigMeta.getWithTokens(["cluster", "config_metadata",NODE_GROUP_ID, "hdp_stack_version"])

## Get the cpu and memory of workers
V_CPU = int(ConfigMeta.getWithTokens(["distros", DISTRO_ID,
        NODE_GROUP_ID, "roles", "worker", "flavor", "cores"]))
V_MEM = int(ConfigMeta.getWithTokens(["distros", DISTRO_ID,
        NODE_GROUP_ID, "roles", "worker", "flavor", "memory"]))

RESERVED_STACK = {4096:1024, 8192:2048, 16384:2048, 24576:4096,
                  49152:6144, 65536:8192, 73728:8192, 98304:12288,
                  131072:24576, 262144:32768, 524288:65536}
RESERVED_HBASE = {4096:1024, 8192:1024, 16384:2048, 24576:4096,
                  49152:8192, 65536:8192, 73728:8192, 98304:16384,
                  131072:24576, 262144:32768, 524288:65536}

APPS_CONTROLLER_COMPONENTS = [{"name": "PIG"},{"name": "HIVE_SERVER"}, {"name": "MYSQL_SERVER"},
                          {"name": "TEZ_CLIENT"},{"name": "HIVE_METASTORE"}, {"name" : "HIVE_CLIENT"},
                          {"name" : "WEBHCAT_SERVER"}, {"name" : "OOZIE_SERVER"},{"name" : "OOZIE_CLIENT"},
                          {"name": "SPARK2_JOBHISTORYSERVER"}, {"name": "LIVY2_SERVER"}]

APPS_NON_CONTROLLER_COMPONENTS = [{"name" : "PIG"}, {"name" : "HCAT"},
                                  {"name" : "TEZ_CLIENT"}, {"name" : "SQOOP"}, {"name" : "HIVE_CLIENT"},
                                  {"name" : "FLUME_HANDLER"}, {"name" : "OOZIE_CLIENT"}]

APPS_EDGE_COMPONENTS = [{"name" : "SPARK2_CLIENT"}, {"name" : "TEZ_CLIENT"},  {"name" : "HIVE_CLIENT"}]


def interpolate_value(map, memory):
    if map.has_key(memory):
        return map[memory]
    keys = map.keys()
    list.sort(keys)
    min_key = keys[0]
    max_key = keys[len(keys) - 1]
    if memory < min_key:
        return map[min_key]
    if memory > max_key:
        return map[max_key]
    for key in keys[1:]:
        if memory < key:
            max_key = key
            break
        min_key = key
    min_value = map[min_key]
    max_value = map[max_key]
    configure_blueprint_logger.info("Min_val={0}, max_val={1}".format(min_value, max_value))
    ret = min_value +\
          ( 1.0 * (memory - min_key)/(max_key - min_key) *\
          (max_value - min_value))
    return ret

def get_reserved_hbase(memory):
    return interpolate_value(RESERVED_HBASE, memory)

def get_reserved_stack(memory):
    return interpolate_value(RESERVED_STACK, memory)

def get_min_container_size(memory):
    if (memory <= 4096):
        return 256
    elif (memory <= 8192):
        return 512
    elif (memory <= 24576):
        return 1024
    else:
        return 2048
    pass

def get_rounded_memory(memory):
    denominator = 128
    if (memory > 4096):
        denominator = 1024
    elif (memory > 2048):
        denominator = 512
    elif (memory > 1024):
        denominator = 256
    else:
        denominator = 128
    return int(math.floor(memory/denominator)) * denominator

def get_yarn_config(yarn_data,mapred_data):
    min_container_size = get_min_container_size(V_MEM)
    reserved_memory = get_reserved_stack(V_MEM)
    configure_blueprint_logger.info("Calculated min_container_size={0}, reserved_memory={1}".format(min_container_size, reserved_memory))
    hbase_memory = get_reserved_hbase(V_MEM)
    reserved_memory += hbase_memory
    memory = max(1024,V_MEM - reserved_memory)
    if (V_MEM < 2):
        memory = 2
    min_container_size = get_min_container_size(memory)
    containers = int(max(3, min(2 * V_CPU, memory/min_container_size)))
    # ram per container in mb
    ram_per_container =  get_rounded_memory(abs(memory/containers))
    configure_blueprint_logger.info("Calculated containers={0}, ram_per_container={1}".format(containers, ram_per_container))
    yarn_config = {
        'yarn.nodemanager.resource.cpu-vcores': V_CPU,
        'yarn.nodemanager.resource.memory-mb': containers * ram_per_container,
        'yarn.scheduler.minimum-allocation-mb': ram_per_container,
        'yarn.scheduler.maximum-allocation-mb': containers * ram_per_container,
        'yarn.scheduler.maximum-allocation-vcores': V_CPU,
        'yarn.nodemanager.local-dirs': HADOOP_DATA_SHUFFLE_DIR + '/yarn/nm',
        'yarn.application.classpath':'$HADOOP_CONF_DIR,/usr/hdp/current/hadoop-client/*,/usr/hdp/current/hadoop-client/lib/*,/usr/hdp/current/hadoop-hdfs-client/*,/usr/hdp/current/hadoop-hdfs-client/lib/*,/usr/hdp/current/hadoop-yarn-client/*,/usr/hdp/current/hadoop-yarn-client/lib/*,' + DTAP_JAR
    }
    yarn_data["yarn-site"]["properties"].update(yarn_config)
    configure_blueprint_logger.info("Setting yarn config to {0}".format(yarn_config))

    mapred_config = {
        'yarn.app.mapreduce.am.resource.mb': int(math.floor(2 * ram_per_container)),
        'mapreduce.map.memory.mb': ram_per_container,
        'mapreduce.reduce.memory.mb': 2 * ram_per_container,
        'mapreduce.map.java.opts': '-Xmx' + str(int(math.floor(0.8 * ram_per_container ))) + 'm',
        'mapreduce.reduce.java.opts': '-Xmx' + str(int(math.floor(0.8 * ram_per_container))) + 'm',
        'mapreduce.task.io.sort.factor': int(min(math.floor(0.4 * ram_per_container), 2047)),
        'mapreduce.job.max.split.locations': str(len(ALL_HOSTS)),
        'mapreduce.application.classpath' : '$PWD/mr-framework/hadoop/share/hadoop/mapreduce/*:$PWD/mr-framework/hadoop/share/hadoop/mapreduce/lib/*:$PWD/mr-framework/hadoop/share/hadoop/common/*:$PWD/mr-framework/hadoop/share/hadoop/common/lib/*:$PWD/mr-framework/hadoop/share/hadoop/yarn/*:$PWD/mr-framework/hadoop/share/hadoop/yarn/lib/*:$PWD/mr-framework/hadoop/share/hadoop/hdfs/*:$PWD/mr-framework/hadoop/share/hadoop/hdfs/lib/*:$PWD/mr-framework/hadoop/share/hadoop/tools/lib/*:/usr/hdp/${hdp.version}/hadoop/lib/hadoop-lzo-0.6.0.${hdp.version}.jar:/etc/hadoop/conf/secure:/opt/bluedata/bluedata-dtap.jar',
        'mapreduce.jobhistory.done-dir' : 'hdfs://mycluster/mr-history/done' if IS_HA else 'hdfs://' + FQDN + ':8020/mr-history/done'  ,
        'mapreduce.jobhistory.intermediate-done-dir' : 'hdfs://mycluster/mr-history/tmp' if IS_HA else 'hdfs://' + FQDN + ':8020/mr-history/tmp'
    }

    mapred_data["mapred-site"]["properties"].update(mapred_config)
    configure_blueprint_logger.info("Setting yarn mapred config to {0}".format(mapred_config))

    return [yarn_data, mapred_data]

def get_security_config(krb_env_data,krb5_conf_data):

    krb_env_config = {
        'realm' : ConfigMeta.getWithTokens(["tenant", "kdc_realm"]),
        'kdc_type' : 'active-directory' if 'Active Directory' in ConfigMeta.getWithTokens(["tenant", "kdc_type"]) else 'mit-kdc',
        'kdc_hosts' : ConfigMeta.getWithTokens(["tenant", "kdc_host"]),
        'admin_server_host' : ConfigMeta.getWithTokens(["tenant", "kdc_host"]),
        "manage_identities": "true"
    }

    DefinedTenantKeys = ConfigMeta.getWithTokens(["tenant"])
    if "krb_enc_types" in DefinedTenantKeys:
        configured_enc_types = ConfigMeta.getWithTokens(["tenant", "krb_enc_types"])
        configured_enc_types = " ".join(configured_enc_types)
        if configured_enc_types != '':
            krb_env_config['encryption_types'] = configured_enc_types

    if krb_env_config['kdc_type'] is 'active-directory':
        krb_env_config['ldap_url'] = "ldaps://"+ConfigMeta.getWithTokens(["tenant", "kdc_host"])
        krb_env_config['container_dn'] = ConfigMeta.getWithTokens(["tenant", "kdc_ad_suffix"])

    krb_env_data["kerberos-env"].update(krb_env_config)
    configure_blueprint_logger.info("Setting Kerberos Env config to {0}".format(krb_env_config))

    krb5_config = {
        "domains" : ConfigMeta.getWithTokens(["tenant", "kdc_realm"]),
        "manage_krb5_conf" : "true" if 'Active Directory' in ConfigMeta.getWithTokens(["tenant", "kdc_type"]) else "false"
    }
    krb5_conf_data["krb5-conf"].update(krb5_config)
    configure_blueprint_logger.info("Setting krb5 config to {0}".format(krb5_config))

    return [krb_env_data,krb5_conf_data]


def update_hostgroups(blueprint):
    for role in ROLES:
        hostgroup = dict(name=role, configurations=[], components=[], cardinality="0+")
        services = [ service for ng in NODEGROUPS
                             for rl in ConfigMeta.getWithTokens(["nodegroups", ng, "roles"])
                             if role == rl
                             for service in ConfigMeta.getWithTokens(["nodegroups", ng, "roles", rl, "services"])
                   ]
        for service in services:
            if service not in ["ssh", "httpd", "AMBARI_AGENT"]:
                hostgroup['components'].append(dict(name=service))
                if service=="NAMENODE" and role==MASTER_1 and not IS_HA:
                    hostgroup['components'].append(dict(name="SECONDARY_NAMENODE"))

        """ 
        if role=="edge" and APPS_ENABLED:
            hostgroup['components'].extend(APPS_EDGE_COMPONENTS)
        """

        configure_blueprint_logger.info("Hostgroup={0}".format(hostgroup))
        blueprint['host_groups'].append(hostgroup)

    """     
    if "edge" not in ROLES:
        hostgroup = dict(name="edge", configurations=[], components=[], cardinality="0+")
        hostgroup['components'].extend([dict(name="ZOOKEEPER_CLIENT"), dict(name="HDFS_CLIENT"),
                                        dict(name="YARN_CLIENT"), dict(name="MAPREDUCE2_CLIENT")])
        if APPS_ENABLED:
            hostgroup['components'].extend(APPS_EDGE_COMPONENTS)

        blueprint['host_groups'].append(hostgroup)
    """


def create_blueprint():
    blueprint = dict(configurations=[], host_groups=[], Blueprints={})
    update_hostgroups(blueprint)

    if IS_HA:
        blueprint['configurations'].append(CORE_SITE_HA)
        blueprint['configurations'].append(HDFS_SITE_HA)
        blueprint['configurations'].extend(get_yarn_config(YARN_SITE_HA, MAPRED_SITE_HA))
        #HBASE_SITE_HA['hbase-site']['properties']['hbase.meta.replica.count'] = len(ALL_HOSTS) - 1
        #blueprint['configurations'].append(HBASE_SITE_HA)
    else:
        blueprint['configurations'].append(CORE_SITE)
        blueprint['configurations'].extend(get_yarn_config(YARN_SITE, MAPRED_SITE))


    blueprint['configurations'].append(HIVE_SITE)
    blueprint['configurations'].append(HIVE_INTERACTIVE_ENV)
    blueprint['configurations'].append(TEZ_SITE)
    blueprint['configurations'].append(LIVY2_CONF)
    blueprint['configurations'].append(LIVY2_ENV)
    blueprint['configurations'].append(SPARK2_ENV)
    #blueprint['configurations'].append(OOZIE_SITE)

    blueprint['Blueprints']['blueprint_name'] = "bd-hdp"
    blueprint['Blueprints']['stack_name'] = "HDP"
    blueprint['Blueprints']['stack_version'] = HDP_STACK_VERSION
    if IS_KERBEROS_ENABLED:
        blueprint['configurations'].extend(get_security_config(KERBEROS_ENV, KRB5_CONF))
        blueprint['Blueprints']['security'] = dict(type="KERBEROS")
    else:
        blueprint['Blueprints']['security'] = dict(type="NONE")
    configure_blueprint_logger.info("Blueprint={0}".format(blueprint))
    return blueprint

def main():

    base_dir = os.environ["CONFIG_BASE_DIR"]
    blueprint = json.dumps(create_blueprint())
    with open(base_dir + '/templates/HDP.blueprint', 'w') as bpfile:
        bpfile.write(blueprint)


if __name__ == '__main__':
    main()
