#!/bin/env python
#
# Copyright (c) 2016, BlueData Software, Inc.
#
# Script which makes ambari rest calls

from bd_vlib import *
import requests, os, time, re, json, logging, sys

ConfigMeta = BDVLIB_ConfigMetadata()
NODE_GROUP = ConfigMeta.getWithTokens(["node",
    "nodegroup_id"])
DISTRO_ID = ConfigMeta.getWithTokens(["node", "distro_id"])
AMBARI_SERVER = ConfigMeta.getWithTokens(["services", "AMBARI_SERVER", NODE_GROUP, "master", "fqdns"])[0]
#APPS_ENABLED = ConfigMeta.getWithTokens(["cluster", "config_choice_selections", NODE_GROUP, "apps"])
print "Ambari Server " + AMBARI_SERVER
AMBARI_URL = 'http://' + AMBARI_SERVER + ':8080/api/v1'
print "Ambari URL " + AMBARI_URL
AUTH = ('admin', 'admin')
HEADERS = {'X-Requested-By': 'ambari'}
ALL_HOSTS = ConfigMeta.getLocalGroupHosts()
# get cluster name and make it hygienic
CLUSTER_NAME = re.sub(r'\W+', '', ConfigMeta.getWithTokens(["cluster", "name"]))
CONFIG_BASE_DIR = os.environ['CONFIG_BASE_DIR']
BLUEDATA_JAR = "/opt/bluedata/bluedata-dtap.jar"

deploy_cluster_logger = logging.getLogger('deploy_cluster_logger')
deploy_cluster_logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
deploy_cluster_logger.addHandler(handler)

def wait_for_agents():
    while True:
        deploy_cluster_logger.info("waiting for agents")
        try:
            resp = requests.get(AMBARI_URL + '/hosts', auth=AUTH, headers=HEADERS)
            if not resp.ok:
                deploy_cluster_logger.info("Error: Received response from ambari " + str(resp.text) + "retrying")
            else:
                deploy_cluster_logger.info("Total number of hosts currently registered with Ambari " + str(len(resp.json().get('items'))))
                deploy_cluster_logger.info("Total number of hosts in cluster " + str(len(ALL_HOSTS)))
                if (len(resp.json().get('items')) == len(ALL_HOSTS)):
                    deploy_cluster_logger.info("All ambari agents successfully registered")
                    break
                else:
                    deploy_cluster_logger.info("Waiting for agents to register.")
                    time.sleep(5)

        except requests.exceptions.ConnectionError:
            print "Ambari Server API Not up yet"
            time.sleep(10)

def post_blueprint():
    data = open(CONFIG_BASE_DIR +'/templates/HDP.blueprint', 'r').read()
    resp = requests.post(AMBARI_URL + '/blueprints/bd-hdp', data=data, auth=AUTH, headers=HEADERS)
    if not resp.ok:
        print "Error: Received response from ambari " + str(resp.text)
    else:
        print "Successfully posted blueprint to ambari"

def post_cluster_json():
    data = open(CONFIG_BASE_DIR + '/cluster.json', 'r').read()
    resp = requests.post(AMBARI_URL + '/clusters/' + CLUSTER_NAME, data=data, auth=AUTH, headers=HEADERS)
    if not resp.ok:
        print "Error: Received response from ambari " + str(resp.text)
    else:
        #Wait for services to start successfully before posting cluster as ready in UI
        service_list = ["HDFS", "YARN", "MAPREDUCE2", "HIVE", "ZOOKEEPER", "SPARK2"]
        for service in service_list:
            wait_for_service(service,"STARTED")
        print "Cluster Started Successfully"


def wait_for_service(service,state):
    count = 0
    while True:
        if count > 600:
            print "Waited 10 mins for service to come up ... service " + service + " are still down check ambari UI and try a manual restart."
            return
        print "Secs waited .." + str(count)
        resp = requests.get(AMBARI_URL + '/clusters/' + CLUSTER_NAME + '/services/' + service, auth=AUTH, headers=HEADERS)
        response_json=json.loads(resp.text)
        if response_json["ServiceInfo"]["state"] in state:
            return
        else:
            time.sleep(5)
            count = count + 5

def main():
    wait_for_agents()
    post_blueprint()
    post_cluster_json()
    BDVLIB_TokenWake('main')

if __name__ == '__main__':
	main()
