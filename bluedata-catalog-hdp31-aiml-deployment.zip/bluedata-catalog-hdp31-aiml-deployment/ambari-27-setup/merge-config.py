#!/usr/bin/python

###------------------------------------------------------------------------------------
### File    : merge-config
###
### Content : 
###
### Copyright 2014 BlueData Software, Inc.
###-------------------------------------------------------------------------------------

import os
import sys,re
from xml.dom.minidom import parse

def usage():
    print "merge-config <input config file path> <updated config file path> <output config file path>"

def readUpdatedConfigFile(fileName):
    properties = {}
    with open(fileName, 'r') as f:
        for line in f:
            line = line.rstrip() #removes trailing whitespace and '\n' chars

            if "=" not in line: continue #skips blanks and comments w/o =
            if line.startswith("#"): continue #skips comments which contain =
            k, v = line.split("=", 1)
            properties[k] = v
    return properties

def alterValueElement(parent, newValue):
    node=parent.getElementsByTagName('value')[0]
    for child in node.childNodes:
        child.data = newValue 

def main(argv):
    if len(argv) != 3:
        usage()
        sys.exit(2)

    input_config_file = argv[0]
    updated_config_file = argv[1]
    merged_config_file = argv[2]

    # Load XML into tree structure
    xmlTree = parse(input_config_file)

    # Find all  <property> tags
    propertyElem_list = xmlTree.getElementsByTagName('configuration')[0].getElementsByTagName('property')
    updatedProperties = readUpdatedConfigFile(updated_config_file)
    for propertyElem in propertyElem_list:
        try:
            name_node = propertyElem.getElementsByTagName('name')[0]
            for child in name_node.childNodes:
                propertyName = child.data.rstrip() #removes trailing whitespace and '\n' chars
                if propertyName in updatedProperties.keys():
                    alterValueElement(propertyElem, updatedProperties[propertyName])
                    updatedProperties.pop(propertyName, None)
        except:
            pass

    for key in updatedProperties.keys():
        newPropertyElement = xmlTree.createElement("property")

        newNameElement = xmlTree.createElement("name")
        newNameTextElement = xmlTree.createTextNode(key.rstrip())
        newNameElement.appendChild (newNameTextElement)
        newPropertyElement.appendChild(newNameElement)

        newValueElement = xmlTree.createElement("value")
        newValueTextElement = xmlTree.createTextNode(updatedProperties[key].rstrip())
        newValueElement.appendChild (newValueTextElement)
        newPropertyElement.appendChild(newValueElement)

        xmlTree.getElementsByTagName('configuration')[0].appendChild(newPropertyElement)

    outfile = open(merged_config_file, "wb")
    xml_string = xmlTree.toprettyxml(indent="  ", encoding="utf-8") 
 
    # strip out the unwanted whitespace that toprettxml() adds 
    fix_re = re.compile('>\n\s+([^<>\s].*?)\n\s+</', re.DOTALL)    
    prettyXml = fix_re.sub('>\g<1></', xml_string)
    prettyXml = re.sub("\n\s+\n+", "\n", prettyXml)

    # write xml to the file
    outfile.write(prettyXml)
    outfile.close()

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
