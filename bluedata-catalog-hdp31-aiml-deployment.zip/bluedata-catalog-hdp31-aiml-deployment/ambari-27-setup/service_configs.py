import logging, sys, math, os
from bd_vlib import *
ConfigMeta = BDVLIB_ConfigMetadata()
NODE_GROUP_ID = ConfigMeta.getWithTokens(["node", "nodegroup_id"])
ZOOKEEPER_ROLES = ConfigMeta.getWithTokens(["services", "ZOOKEEPER_SERVER", NODE_GROUP_ID])
MASTER_1 = ConfigMeta.getWithTokens(["cluster", "config_metadata", NODE_GROUP_ID, "master_1"])
MASTER_2 = ConfigMeta.getWithTokens(["cluster", "config_metadata", NODE_GROUP_ID, "master_2"])
MASTER_3 = ConfigMeta.getWithTokens(["cluster", "config_metadata", NODE_GROUP_ID, "master_3"])
IS_HA = ConfigMeta.getWithTokens(["cluster", "config_choice_selections",NODE_GROUP_ID, "all_ha"])
ALL_HOSTS = ConfigMeta.getClusterHostsFQDN()
if IS_HA:
    ZK_QUORUM = "%HOSTGROUP::" + ZOOKEEPER_ROLES[0] + "%:2181,%HOSTGROUP::" + ZOOKEEPER_ROLES[1] + "%:2181,%HOSTGROUP::" \
                + ZOOKEEPER_ROLES[2] + "%:2181"
    NAMENODE_SHARED_EDITS_DIR = "qjournal://%HOSTGROUP::" + ZOOKEEPER_ROLES[0] + "%:8485;%HOSTGROUP::" + ZOOKEEPER_ROLES[1] + \
                                "%:8485;%HOSTGROUP::" + ZOOKEEPER_ROLES[2] + "%:8485/mycluster"
else:
    ZK_QUORUM = ""
    NAMENODE_SHARED_EDITS_DIR = ""


CORE_SITE_HA = {
    "core-site" : {
        "properties_attributes" : { },
        "properties" : {
            "fs.defaultFS" : "hdfs://mycluster",
            "ha.zookeeper.quorum" : ZK_QUORUM,
            "fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
            "fs.dtap.impl.disable.cache": "false",
            "fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
            "hadoop.proxyuser.hue.hosts" : "*",
            "hadoop.proxyuser.hue.groups" : "*",
            "hadoop.proxyuser.hcat.groups" : "*",
            "hadoop.proxyuser.hcat.hosts" : "*",
            "hadoop.proxyuser.oozie.hosts" : "*",
            "hadoop.proxyuser.oozie.groups" : "*",
            "hadoop.proxyuser.hdfs.groups" : "*",
            "hadoop.proxyuser.hdfs.hosts" : "*",
            "hadoop.proxyuser.hive.groups" : "*",
            "hadoop.proxyuser.hive.hosts" : "*",
            "hadoop.proxyuser.httpfs.hosts" : "*",
            "hadoop.proxyuser.httpfs.groups" : "*",
            "hadoop.proxyuser.root.groups" : "*",
            "hadoop.proxyuser.root.hosts" : "*",
            "hadoop.proxyuser.admin.groups" : "*",
            "hadoop.proxyuser.admin.hosts" : "*",
            "hadoop.proxyuser.ambari.groups" : "*",
            "hadoop.proxyuser.ambari.hosts" : "*"
        }
    }
}

HBASE_SITE_HA = {
    "hbase-site" : {
        "properties_attributes" : { },
        "properties" : {
            "hbase.rootdir" : "hdfs://mycluster/apps/hbase/data",
            "hbase.region.replica.replication.enabled": "true",
            "hbase.master.loadbalancer.class": "org.apache.hadoop.hbase.master.balancer.StochasticLoadBalancer",
            "hbase.meta.replica.count": len(ALL_HOSTS) -1,
            "hbase.region.replica.wait.for.primary.flush": "true",
            "hbase.ipc.client.specificThreadForWriting": "true",
            "hbase.meta.replicas.use": "true"
        }
    }
}

HDFS_SITE_HA = {
    "hdfs-site": {
        "properties" : {
            "dfs.client.failover.proxy.provider.mycluster": "org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider",
            "dfs.ha.automatic-failover.enabled": "true",
            "dfs.ha.fencing.methods": "shell(/bin/true)",
            "dfs.ha.namenodes.mycluster": "nn1,nn2",
            "dfs.namenode.http-address": "%HOSTGROUP::" + MASTER_1 + "%:50070",
            "dfs.namenode.http-address.mycluster.nn1": "%HOSTGROUP::" + MASTER_1 + "%:50070",
            "dfs.namenode.http-address.mycluster.nn2": "%HOSTGROUP::" + MASTER_2 + "%:50070",
            "dfs.namenode.https-address" : "%HOSTGROUP::" + MASTER_1 + "%:50470",
            "dfs.namenode.https-address.mycluster.nn1": "%HOSTGROUP::" + MASTER_1 + "%:50470",
            "dfs.namenode.https-address.mycluster.nn2": "%HOSTGROUP::" + MASTER_2 + "%:50470",
            "dfs.namenode.rpc-address.mycluster.nn1": "%HOSTGROUP::" + MASTER_1 + "%:8020",
            "dfs.namenode.rpc-address.mycluster.nn2": "%HOSTGROUP::" + MASTER_2 + "%:8020",
            "dfs.namenode.secondary.http-address": "%HOSTGROUP::" + MASTER_3 + "%:50090",
            "dfs.namenode.shared.edits.dir": NAMENODE_SHARED_EDITS_DIR,
            "dfs.nameservices" : "mycluster"
        }
    }
}

YARN_SITE_HA = {
    "yarn-site": {
        "properties" : {
            "hadoop.registry.rm.enabled" : "false",
            "hadoop.registry.zk.quorum" : ZK_QUORUM,
            "yarn.log.server.url" : "http://%HOSTGROUP::" + MASTER_2 + "%:19888/jobhistory/logs",
            "yarn.resourcemanager.address" : "%HOSTGROUP::" + MASTER_1 + "%:8050",
            "yarn.resourcemanager.admin.address" : "%HOSTGROUP::" + MASTER_1 + "%:8141",
            "yarn.resourcemanager.cluster-id" : "yarn-cluster",
            "yarn.resourcemanager.ha.automatic-failover.zk-base-path" : "/yarn-leader-election",
            "yarn.resourcemanager.ha.enabled" : "true",
            "yarn.resourcemanager.ha.rm-ids" : "rm1,rm2",
            "yarn.resourcemanager.hostname" : "%HOSTGROUP::" + MASTER_1 + "%",
            "yarn.resourcemanager.hostname.rm1" : "%HOSTGROUP::" + MASTER_1 + "%",
            "yarn.resourcemanager.hostname.rm2" : "%HOSTGROUP::" + MASTER_2 + "%",
            "yarn.resourcemanager.webapp.address.rm1" : "%HOSTGROUP::" + MASTER_1 + "%:8088",
            "yarn.resourcemanager.webapp.address.rm2" : "%HOSTGROUP::" + MASTER_2 + "%:8088",
            "yarn.resourcemanager.recovery.enabled" : "true",
            "yarn.resourcemanager.resource-tracker.address" : "%HOSTGROUP::" + MASTER_1 + "%:8025",
            "yarn.resourcemanager.scheduler.address" : "%HOSTGROUP::" + MASTER_1 + "%:8030",
            "yarn.resourcemanager.store.class" : "org.apache.hadoop.yarn.server.resourcemanager.recovery.ZKRMStateStore",
            "yarn.resourcemanager.webapp.address" : "%HOSTGROUP::" + MASTER_1 + "%:8088",
            "yarn.resourcemanager.webapp.https.address" : "%HOSTGROUP::" + MASTER_1 + "%:8090",
            "yarn.timeline-service.address" : "%HOSTGROUP::" + MASTER_1 + "%:10200",
            "yarn.timeline-service.webapp.address" : "%HOSTGROUP::" + MASTER_1 + "%:8188",
            "yarn.timeline-service.webapp.https.address" : "%HOSTGROUP::" + MASTER_1 + "%:8190"
        }
    }
}


MAPRED_SITE_HA = {
    "mapred-site" : {
        "properties_attributes": {},
        "properties": {

        }
    }
}

CORE_SITE = {
    "core-site": {
        "properties_attributes": {},
        "properties": {
            "fs.dtap.impl": "com.bluedata.hadoop.bdfs.Bdfs",
            "fs.dtap.impl.disable.cache": "false",
            "fs.AbstractFileSystem.dtap.impl": "com.bluedata.hadoop.bdfs.BdAbstractFS",
            "hadoop.proxyuser.hue.hosts": "*",
            "hadoop.proxyuser.hue.groups": "*",
            "hadoop.proxyuser.hcat.groups": "*",
            "hadoop.proxyuser.hcat.hosts": "*",
            "hadoop.proxyuser.oozie.hosts": "*",
            "hadoop.proxyuser.oozie.groups": "*",
            "hadoop.proxyuser.hdfs.groups": "*",
            "hadoop.proxyuser.hdfs.hosts": "*",
            "hadoop.proxyuser.hive.groups": "*",
            "hadoop.proxyuser.hive.hosts": "*",
            "hadoop.proxyuser.httpfs.hosts": "*",
            "hadoop.proxyuser.httpfs.groups": "*",
            "hadoop.proxyuser.root.groups": "*",
            "hadoop.proxyuser.root.hosts": "*",
            "hadoop.proxyuser.admin.groups": "*",
            "hadoop.proxyuser.admin.hosts": "*",
            "hadoop.proxyuser.ambari.groups": "*",
            "hadoop.proxyuser.ambari.hosts": "*"
        }
    }
}

YARN_SITE = {
    "yarn-site" : {
        "properties_attributes" : { },
        "properties" : {

        }
    }
}

MAPRED_SITE = {
    "mapred-site" : {
        "properties_attributes" : { },
        "properties" : {

        }
    }
}

HIVE_SITE = {
    "hive-site" : {
        "properties_attributes" : { },
        "properties" : {
            "javax.jdo.option.ConnectionPassword" : "hive",
            "hive.aux.jars.path": "file:///opt/bluedata/bluedata-dtap.jar",
            "hive.tez.java.opts" : "-server -Djava.net.preferIPv4Stack=true -XX:NewRatio=8 -XX:+UseG1GC -XX:+ResizeTLAB -XX:+PrintGCDetails -verbose:gc -XX:+PrintGCTimeStamps",
        }
    }
}

HIVE_INTERACTIVE_ENV = {
    "hive-interactive-env" : {
        "properties_attributes" : { },
        "properties" : {

            "llap_java_opts" : "-XX:+AlwaysPreTouch -XX:+UseG1GC -XX:TLABSize=8m -XX:+ResizeTLAB -XX:+AggressiveOpts -XX:InitiatingHeapOccupancyPercent=70 -XX:+UnlockExperimentalVMOptions -XX:G1MaxNewSizePercent=40 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=200{{heap_dump_opts}}"
        }
    }
}

TEZ_SITE = {
    "tez-site" : {
        "properties_attributes" : { },
        "properties" : {
            "tez.cluster.additional.classpath.prefix" : "/usr/hdp/${hdp.version}/hadoop/lib/hadoop-lzo-0.6.0.${hdp.version}.jar:/etc/hadoop/conf/secure:/opt/bluedata/bluedata-dtap.jar",
            "tez.am.launch.cmd-opts" : "-XX:+PrintGCDetails -verbose:gc -XX:+PrintGCTimeStamps -XX:+UseG1GC -XX:+ResizeTLAB{{heap_dump_opts}}",
            "tez.task.launch.cmd-opts" : "-XX:+PrintGCDetails -verbose:gc -XX:+PrintGCTimeStamps -XX:+UseG1GC -XX:+ResizeTLAB{{heap_dump_opts}}"
        }
    }
}

OOZIE_SITE = {
    "oozie-site" : {
        "properties_attributes" : { },
        "properties" : {
            "oozie.service.JPAService.jdbc.driver" : "org.postgresql.Driver",
            "oozie.service.JPAService.jdbc.url" : "jdbc:postgresql://localhost:5432/oozie",
            "oozie.service.JPAService.jdbc.username" : "oozie",
            "oozie.service.JPAService.jdbc.password" : "oozie"
        }
    }
}

KERBEROS_ENV = {
    "kerberos-env": {
        "properties_attributes" : { },
        "properties" : {

        }
    }
}

KRB5_CONF = {
    "krb5-conf": {
        "properties_attributes" : { },
        "properties" : {

        }
    }
}


LIVY2_CONF = {
    "livy2-conf": {
        "properties_attributes" : { },
        "properties" : {
            "livy.server.csrf_protection.enabled" : "false"
        }

    }
}

LIVY2_ENV = {
    "livy2-env": {
        "properties_attributes" : { },
        "properties" : {
            "content" : "\n            #!/usr/bin/env bash\n\n            # - SPARK_HOME      Spark which you would like to use in livy\n            # - SPARK_CONF_DIR  Directory containing the Spark configuration to use.\n            # - HADOOP_CONF_DIR Directory containing the Hadoop / YARN configuration to use.\n            # - LIVY_LOG_DIR    Where log files are stored.  (Default: ${LIVY_HOME}/logs)\n            # - LIVY_PID_DIR    Where the pid file is stored. (Default: /tmp)\n            # - LIVY_SERVER_JAVA_OPTS  Java Opts for running livy server (You can set jvm related setting here, like jvm memory/gc algorithm and etc.)\n            export SPARK_HOME=/usr/hdp/current/spark2-client\n            export SPARK_CONF_DIR=/etc/spark2/conf\n            export JAVA_HOME={{java_home}}\n            export HADOOP_CONF_DIR=/etc/hadoop/conf\n            export LIVY_LOG_DIR={{livy2_log_dir}}\n            export LIVY_PID_DIR={{livy2_pid_dir}}\n            export LIVY_SERVER_JAVA_OPTS=\"-Xmx2g\" \n  export PYSPARK_PYTHON=/opt/miniconda/bin/python \n export PYSPARK_DRIVER_PYTHON=/opt/miniconda/bin/python"
        }

    }
}

SPARK2_ENV = {
    "spark2-env": {
        "properties_attributes": {},
        "properties": {
            "content": "\n#!/usr/bin/env bash\n\n# This file is sourced when running various Spark programs.\n# Copy it as spark-env.sh and edit that to configure Spark for your site.\n\n# Options read in YARN client mode\n#SPARK_EXECUTOR_INSTANCES=\"2\" #Number of workers to start (Default: 2)\n#SPARK_EXECUTOR_CORES=\"1\" #Number of cores for the workers (Default: 1).\n#SPARK_EXECUTOR_MEMORY=\"1G\" #Memory per Worker (e.g. 1000M, 2G) (Default: 1G)\n#SPARK_DRIVER_MEMORY=\"512M\" #Memory for Master (e.g. 1000M, 2G) (Default: 512 Mb)\n#SPARK_YARN_APP_NAME=\"spark\" #The name of your application (Default: Spark)\n#SPARK_YARN_QUEUE=\"default\" #The hadoop queue to use for allocation requests (Default: default)\n#SPARK_YARN_DIST_FILES=\"\" #Comma separated list of files to be distributed with the job.\n#SPARK_YARN_DIST_ARCHIVES=\"\" #Comma separated list of archives to be distributed with the job.\n\n{% if security_enabled %}\nexport SPARK_HISTORY_OPTS='-Dspark.ui.filters=org.apache.hadoop.security.authentication.server.AuthenticationFilter -Dspark.org.apache.hadoop.security.authentication.server.AuthenticationFilter.params=\"type=kerberos,kerberos.principal={{spnego_principal}},kerberos.keytab={{spnego_keytab}}\"'\n{% endif %}\n\n\n# Generic options for the daemons used in the standalone deploy mode\n\n# Alternate conf dir. (Default: ${SPARK_HOME}/conf)\nexport SPARK_CONF_DIR=${SPARK_CONF_DIR:-{{spark_home}}/conf}\n\n# Where log files are stored.(Default:${SPARK_HOME}/logs)\n#export SPARK_LOG_DIR=${SPARK_HOME:-{{spark_home}}}/logs\nexport SPARK_LOG_DIR={{spark_log_dir}}\n\n# Where the pid file is stored. (Default: /tmp)\nexport SPARK_PID_DIR={{spark_pid_dir}}\n\n#Memory for Master, Worker and history server (default: 1024MB)\nexport SPARK_DAEMON_MEMORY={{spark_daemon_memory}}m\n\n# A string representing this instance of spark.(Default: $USER)\nSPARK_IDENT_STRING=$USER\n\n# The scheduling priority for daemons. (Default: 0)\nSPARK_NICENESS=0\n\nexport HADOOP_HOME=${HADOOP_HOME:-{{hadoop_home}}}\nexport HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-{{hadoop_conf_dir}}}\n\n# The java implementation to use.\nexport JAVA_HOME={{java_home}}\n\nexport PYSPARK_PYTHON=/opt/miniconda/bin/python \nexport PYSPARK_DRIVER_PYTHON=/opt/miniconda/bin/python"
        }
    }
}
