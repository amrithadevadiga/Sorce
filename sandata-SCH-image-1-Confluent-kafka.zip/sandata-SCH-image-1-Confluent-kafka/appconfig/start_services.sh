#!/bin/sh
set -o pipefail
SELF=$(readlink -nf $0)
export CONFIG_BASE_DIR=$(dirname ${SELF})
source ${CONFIG_BASE_DIR}/logging.sh
source ${CONFIG_BASE_DIR}/utils.sh
source ${CONFIG_BASE_DIR}/macros.sh

ROLE_ID_RUNNING_ZOOKEEPER=$(invoke_bdvcli --get services.zookeeper.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
ZOOKEEPER=$(invoke_bdvcli --get services.zookeeper.1.$ROLE_ID_RUNNING_ZOOKEEPER.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a ZOOKEEPER_LIST <<< "$ZOOKEEPER"
COUNT_ZOOKEEPER_LIST=`echo ${#ZOOKEEPER_LIST[@]}`
FQDN="$(invoke_bdvcli --get node.fqdn)"
ROLE="$(invoke_bdvcli --get node.role_id)"
#
#

# List of roles to map to servicesin Large environment
#                Confluent_Control_Center,
#                Kafka_Zookeeper,
#                Kafka_Broker,
#                Kafka_Schema_Registry,
#                Kafka_REST_Proxy",
#                Kafka_Connect,
#                Kafka_SQL_Server


	if [[ "${ROLE}" == "Confluent_Control_Center" ]]; then
		REGISTER_START_SERVICE_SYSCTL control-center confluent-control-center 
	fi
	if [[ "$ROLE}" == "Kafka_REST_Proxy" ]]; then
		REGISTER_START_SERVICE_SYSCTL rest-proxy confluent-kafka-rest 
	fi
	if [[ "${ROLE}" == "Kafka_Zookeeper" ]]; then
	        j=1;
                for ((i=0;i < $COUNT_ZOOKEEPER_LIST;i++)){
                        j=`expr $i + 1`
                        if [[ "${ZOOKEEPER_LIST[$i]}" == "${FQDN}" ]]; then
                                echo "${j}" > /var/lib/zookeeper/myid
                        fi
                }      
		REGISTER_START_SERVICE_SYSCTL zookeeper confluent-zookeeper
	fi
	if [[ "${ROLE}" == "Kafka_Broker" ]]; then
		REGISTER_START_SERVICE_SYSCTL kafka confluent-kafka 
	fi
	if [[ "${ROLE}" == "Kafka_SQL_Server" ]]; then
		REGISTER_START_SERVICE_SYSCTL ksql confluent-ksql 
	fi
	if [[ "${ROLE}" == "Kafka_Schema_Registry" ]]; then
		REGISTER_START_SERVICE_SYSCTL schema-registry confluent-schema-registry
	fi
	if [[ "${ROLE}" == "Kafka_Connect" ]]; then 
   		cp ${CONFIG_BASE_DIR}/kafka_connect_hadoopuser.service /etc/systemd/system/
		REGISTER_START_SERVICE_SYSCTL kafka_connect_hadoopuser kafka_connect_hadoopuser
	fi
