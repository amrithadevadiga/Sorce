#!/bin/sh
set -o pipefail
SELF=$(readlink -nf $0)
export CONFIG_BASE_DIR=$(dirname ${SELF})
source ${CONFIG_BASE_DIR}/logging.sh
source ${CONFIG_BASE_DIR}/utils.sh
source ${CONFIG_BASE_DIR}/macros.sh
CLUSTER_NAME="$(invoke_bdvcli --get cluster.name)"
FQDN="$(invoke_bdvcli --get node.fqdn)"
ROLE="$(invoke_bdvcli --get node.role_id)"
#
# All Nodes list and count
#
ALL_NODES=$(invoke_bdvcli --get_local_group_fqdns | egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a NODES_LIST <<< "$ALL_NODES"
NODE_COUNT=`echo ${#NODES_LIST[@]}`
#
# My node roles
#
MY_ROLE=$(invoke_bdvcli --get node.role_id | egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
#IFS=', ' read -r -a MY_ROLES_LIST <<< "$MY_ROLES"
#ROLE_COUNT=`echo ${#MY_ROLES_LIST[@]}`
#
# All Services list and count
#
ALL_SERVICES=$(invoke_bdvcli --get services | egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a SERVICES_LIST <<< "$ALL_SERVICES"
SERVICES_COUNT=`echo ${#SERVICES_LIST[@]}`
#
# All Groups IDs and count
#
ALL_GROUPS_IDS=$(invoke_bdvcli --get cluster.config_choice_selections | egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a GROUPS_IDS_LIST <<< "$ALL_GROUPS_IDS"
GROUP_IDS_COUNT=`echo ${#GROUPS_IDS_LIST[@]}`
#
# Assumption only 1 group ID,${GROUPS_IDS_LIST[0]} of value 1, no Edge nodes defined in this
#
# Construct ZOOKEEPER_SERVERS_LIST:2181
#
ZOOKEEPER_SERVERS_LIST=""
ROLE_ID_RUNNING_ZOOKEEPER=$(invoke_bdvcli --get services.zookeeper.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
ZOOKEEPER=$(invoke_bdvcli --get services.zookeeper.1.$ROLE_ID_RUNNING_ZOOKEEPER.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a ZOOKEEPER_LIST <<< "$ZOOKEEPER"
COUNT_ZOOKEEPER_LIST=`echo ${#ZOOKEEPER_LIST[@]}`

ZOOKEEPER_SERVERS_LIST=${ZOOKEEPER_LIST[0]}:2181
for ((i=1;i < $COUNT_ZOOKEEPER_LIST;i++)){
	ZOOKEEPER_SERVERS_LIST=$ZOOKEEPER_SERVERS_LIST,${ZOOKEEPER_LIST[$i]}:2181
}

#
# Construct CONNECT_SERVERS_LIST:8083
#
CONNECT_SERVERS_LIST=""
ROLE_ID_RUNNING_CONNECT=$(invoke_bdvcli --get services.kafka_connect_hadoopuser.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
CONNECT=$(invoke_bdvcli --get services.kafka_connect_hadoopuser.1.$ROLE_ID_RUNNING_CONNECT.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a CONNECT_LIST <<< "$CONNECT"
COUNT_CONNECT_LIST=`echo ${#CONNECT_LIST[@]}`

CONNECT_SERVERS_LIST=${CONNECT_LIST[0]}:8083
for ((i=1;i < $COUNT_CONNECT_LIST;i++)){
	CONNECT_SERVERS_LIST=$CONNECT_SERVERS_LIST,${CONNECT_LIST[$i]}:8083
}

#
# Construct KAFKA_BROKER_SERVERS_LIST:9092
#
KAFKA_BROKER_SERVERS_LIST=""
PT_KAFKA_BROKER_SERVERS_LIST=""

ROLE_ID_RUNNING_BROKER=$(invoke_bdvcli --get services.kafka.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
KAFKA_BROKER=$(invoke_bdvcli --get services.kafka.1.$ROLE_ID_RUNNING_BROKER.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a KAFKA_BROKER_LIST <<< "$KAFKA_BROKER"
COUNT_KAFKA_BROKER_LIST=`echo ${#KAFKA_BROKER_LIST[@]}`

KAFKA_BROKER_SERVERS_LIST=${KAFKA_BROKER_LIST[0]}:9092
PT_KAFKA_BROKER_SERVERS_LIST=PLAINTEXT://${KAFKA_BROKER_LIST[0]}:9092

for ((i=1;i < $COUNT_KAFKA_BROKER_LIST;i++)){
	KAFKA_BROKER_SERVERS_LIST=$KAFKA_BROKER_SERVERS_LIST,${KAFKA_BROKER_LIST[$i]}:9092
	PT_KAFKA_BROKER_SERVERS_LIST=$PT_KAFKA_BROKER_SERVERS_LIST,PLAINTEXT://${KAFKA_BROKER_LIST[$i]}:9092
}
PLAINTEXT_KAFKA_BROKER_SERVERS_LIST="$(echo "$PT_KAFKA_BROKER_SERVERS_LIST"| sed -e 's/\//\\\//g')"
#
# Construct PROXY_SERVERS_LIST:8082
#
PROXY_SERVERS_LIST=""
PROXY_SERVERS_LIST_HTTP=""
ROLE_ID_RUNNING_PROXY=$(invoke_bdvcli --get services.rest-proxy.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')

PROXY_SERVERS=$(invoke_bdvcli --get services.rest-proxy.1.$ROLE_ID_RUNNING_PROXY.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a PROXY_LIST <<< "$PROXY_SERVERS"
COUNT_PROXY_LIST=`echo ${#PROXY_LIST[@]}`

PROXY_SERVERS_LIST=${PROXY_LIST[0]}:8082
PROXY_SERVERS_LIST_HTTP=http://${PROXY_LIST[0]}:8082
for ((i=1;i < $COUNT_PROXY_LIST;i++)){
	PROXY_SERVERS_LIST=$PROXY_SERVERS_LIST,${PROXY_LIST[$i]}:8082
	PROXY_SERVERS_LIST_HTTP=$PROXY_SERVERS_LIST_HTTP,http://${PROXY_LIST[$i]}:8082
}
PROXY_SERVERS_LIST_HTTP_CONF="$(echo "$PROXY_SERVERS_LIST_HTTP"| sed -e 's/\//\\\//g')"
#
#Construct SCHEMA_REGISTRY_LIST:8081
#
SCHEMA_SERVERS_LIST=""
ROLE_ID_RUNNING_SCHEMA=$(invoke_bdvcli --get services.schema-registry.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')

SCHEMA_SERVERS=$(invoke_bdvcli --get services.schema-registry.1.$ROLE_ID_RUNNING_SCHEMA.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a SCHEMA_LIST <<< "$SCHEMA_SERVERS"
COUNT_SCHEMA_LIST=`echo ${#SCHEMA_LIST[@]}`

SCHEMA_SERVERS_LIST=http:\/\/${SCHEMA_LIST[0]}:8081
for ((i=1;i < $COUNT_SCHEMA_LIST;i++)){
	SCHEMA_SERVERS_LIST=$SCHEMA_SERVERS_LIST,http:\/\/${SCHEMA_LIST[$i]}:8081
}
SCHEMA_SERVERS_LIST_HTTP=$(echo "$SCHEMA_SERVERS_LIST"| sed -e 's/\//\\\//g')
#
#Construct KSQL list, we take only first one
#
KSQL_SERVERS_LIST=""
ROLE_ID_RUNNING_KSQL=$(invoke_bdvcli --get services.ksql.1| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')

KSQL_SERVERS=$(invoke_bdvcli --get services.ksql.1.$ROLE_ID_RUNNING_KSQL.fqdns| egrep -o "[^, ]+" | sort -V | xargs | sed -e 's/ /,/g')
IFS=', ' read -r -a KSQL_LIST <<< "$KSQL_SERVERS"
KSQL_SERVERS=${KSQL_LIST[0]}

#
# List of roles to map to services in Large environment
#                Confluent_Control_Center,
#                Kafka_Zookeeper,
#                Kafka_Broker,
#                Kafka_Schema_Registry,
#                Kafka_REST_Proxy",
#                Kafka_Connect,
#                Kafka_SQL_Server
#
#
 	if [[ "${MY_ROLE}" == "Kafka_SQL_Server" ]]; then
#		mkdir -p /usr/logs/ksql-cli/  
#		chmod 777 -Rf /usr/logs/ksql-cli/
#		mkdir -p /var/lib/kafka-streams
#		chmod -Rf 777 /var/lib/kafka-streams
#		mkdir -p /usr/ui/expanded
#		mv /ksql-experimental-ui-0.1.war /usr/ui/
#		chown -Rf  cp-ksql:confluent /usr/ui/*
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/ksql/ksql-server.properties
		sed --i s/@@@@SCHEMA_SERVERS_LIST@@@@/$SCHEMA_SERVERS_LIST_HTTP/g /etc/ksql/ksql-server.properties		
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@MY_HOSTNAME@@@@/$FQDN/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/consumer.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/producer.properties
	fi
	if [[ "${MY_ROLE}" == "Confluent_Control_Center" ]]; then
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/confluent-control-center/control-center-production.properties
		sed --i s/@@@@CONNECT_SERVERS_LIST@@@@/$CONNECT_SERVERS_LIST/g /etc/confluent-control-center/control-center-production.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/confluent-control-center/control-center-production.properties
		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/confluent-control-center/control-center-production.properties
		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@MY_HOSTNAME@@@@/$FQDN/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/consumer.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/producer.properties
		sed --i s/@@@@KSQL_SERVERS@@@@/$KSQL_SERVERS/g /etc/confluent-control-center/control-center-production.properties 
		sed --i s/@@@@SCHEMA_REGISTRY_SERVERS@@@@/${SCHEMA_LIST[0]}/g /etc/confluent-control-center/control-center-production.properties 
	fi		
	if [[ "${MY_ROLES}" == "Kafka_REST_Proxy" ]]; then
		mkdir -p /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
   		chmod -R ag+w /etc/kafka /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
		chmod -Rf 777 /var/lib/kafka-streams
   		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
   		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties

		sed --i s/@@@@PROXY_SERVERS_LIST_HTTP_CONF@@@@/$PROXY_SERVERS_LIST_HTTP_CONF/g /etc/kafka-rest/kafka-rest.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka-rest/kafka-rest.properties
		sed --i s/@@@@PLAINTEXT_KAFKA_BROKER_SERVERS_LIST@@@@/$PLAINTEXT_KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-rest/kafka-rest.properties
	fi
	if [[ "${MY_ROLE}" == "Kafka_Zookeeper" ]]; then
		mkdir -p /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams /var/lib/zookeeper/
		chmod -R ag+w /etc/kafka /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
		chmod -Rf 777 /var/lib/kafka-streams
		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
   		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties
		j=1;
		for ((i=0;i < $COUNT_ZOOKEEPER_LIST;i++)){
        		j=`expr $i + 1`
			echo "server.${j}=${ZOOKEEPER_LIST[$i]}:2888:3888" >> /etc/kafka/zookeeper.properties
		}
	fi
	if [[ "${MY_ROLE}" == "Kafka_Broker" ]]; then
		mkdir -p /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
   		chmod -R ag+w /etc/kafka /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
		chmod -Rf 777 /var/lib/kafka-streams
   		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
   		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka/connect-distributed.properties
	fi
	if [[ "${MY_ROLE}" == "Kafka_Schema_Registry" ]]; then
		mkdir -p /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
   		chmod -R ag+w /etc/kafka /var/lib/kafka/data /etc/kafka/secrets /var/lib/kafka-streams
		chmod -Rf 777 /var/lib/kafka-streams
   		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties	
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/schema-registry/connect-avro-standalone.properties
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/schema-registry/connect-avro-distributed.properties
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/schema-registry/connect-avro-distributed.properties

		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka/connect-distributed.properties
		
   		sed --i s/@@@@PLAINTEXT_KAFKA_BROKER_SERVERS_LIST@@@@/$PLAINTEXT_KAFKA_BROKER_SERVERS_LIST/g /etc/schema-registry/schema-registry.properties
   		sed --i s/@@@@MY_FQDN@@@@/$FQDN/g /etc/schema-registry/schema-registry.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/schema-registry/schema-registry.properties
		sed --i s/SCHEMA_REGISTRY_OPTS=\"\"/SCHEMA_REGISTRY_OPTS=\"-Djava.net.preferIPv4Addresses=true -Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Stack=false\"/g /usr/bin/schema-registry-run-class
	fi
	if [[ "${MY_ROLE}" == "Kafka_Connect" ]]; then
		mkdir -p /var/lib/kafka-connect/data /etc/kafka-connect/secrets /var/lib/kafka-streams
   		chmod -R ag+w /etc/kafka-connect /var/lib/kafka-connect/data /etc/kafka-connect/secrets /var/lib/kafka-streams
		chmod -Rf 777 /var/lib/kafka-streams
   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/server.properties
   		sed --i s/@@@@FQDN@@@@/$FQDN/g /etc/kafka/server.properties
   		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g /etc/kafka/server.properties

   		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@MY_HOSTNAME@@@@/$FQDN/g /etc/kafka/connect-distributed.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/consumer.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka/producer.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g  /etc/kafka-connect-replicator/quickstart-replicator-unicluster.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-connect-replicator/quickstart-replicator-unicluster.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-connect-replicator/replicator-connect-distributed.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g  /etc/kafka-connect-replicator/replicator-connect-distributed.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-connect-replicator/replicator-connect-distributed.properties
		sed --i s/@@@@NAME_CLUSTER@@@@/$CLUSTER_NAME/g /etc/kafka-connect-replicator/replicator-connect-distributed.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-connect-replicator/replicator-connect-standalone.properties
		sed --i s/@@@@KAFKA_BROKER_SERVERS_LIST@@@@/$KAFKA_BROKER_SERVERS_LIST/g /etc/kafka-connect-replicator/replicator.properties
		sed --i s/@@@@ZOOKEEPER_SERVERS_LIST@@@@/$ZOOKEEPER_SERVERS_LIST/g  /etc/kafka-connect-replicator/replicator.properties
	fi
