Spark240-notebook:

  List of changes/features:

>> Support for PamD issue. (Multiple AD/LDAP users can login in to their Individual work space in JupyterHub)
>> Support for Jupyterlab and SSL configuration.
>> Spark Master node cardinality restricted to 1.

  EPIC versions this bin file is intended for: 

>> Post 3.7

  Jobs and/or action scripts to test the image:

>> https://docs.google.com/document/d/1EMLS2JOhMRChTe6-PTd71AHLWAlKFgujRFzH4HHi868/edit#heading=h.kpk47emld0gr

  RELEASE NOTES:

>> Please use classic jupyter notebook for accessing any Toree kernels instead of JupyterLab. JupyterLab doesn't support Toree kernels.
