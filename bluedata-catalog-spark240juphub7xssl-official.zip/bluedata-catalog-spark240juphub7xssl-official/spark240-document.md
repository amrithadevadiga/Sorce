# Overview

In this image, the user can access Spark-2.4.0 master and workers, Rstudio, Jupyterhub, and Spark gateway. It has packages like Python 3.6.0,Anaconda3-5.1.0 and Jupyter Toree kernels - Scala, PySpark, SQL along with Sparkling water 2.3.11.

## What is {name}?

Apache Spark is an open source, general-purpose distributed computing engine used for processing and analyzing a large amount of data. Just like Hadoop MapReduce, it also works with the system to distribute data across the cluster and process the data in parallel.

For more details about Spark240, refer to this link:
[Spark2.4_docs](https://spark.apache.org/docs/2.4.0/)


# Details:
## Application Image Details:

### AppName: 
{name}
### DistroId:
{distroid}
### Version: 
{version}

### Cluster Type: 
Notebooks
### Software Included: 
- Jupyterhub version - 0.8.1, 
- Python 3.6.0 |Anaconda3-5.1.0 (64-bit), 
- R version 3.5.1 (2018-07-02),
- R libraries pre-installed on all nodes - sparklyr, devtools, knitr, tidyr, ggplot2, shiny
- R Hadoop client for accessing HDFS from R - rHadoopClient_0.2.tar.gz,
- Spark-2.4.0-bin-hadoop2.7 configured to run on Python 3,
- Jupyter Toree kernels - Scala, PySpark, SQL (toree-0.2.0.dev1.tar.gz),
- Sparkling water 2.3.11.

### Notebook access:   
- Jupyterhub server  - Create an OS user for each user who needs access on cluster controller node.
    ‘sudo useradd test’
    ‘sudo passwd test’ -> provide a password 
    Login with test/password
- Rstudio pam.d modules need to be configured to login. Run this [ActionScript](https://github.com/bluedatainc/solutions/blob/master/ActionScripts/scripts/create_user.sh) on rstudio node upon cluster creation to configure login for users.
- SPARK_HOME: /usr/lib/spark/spark-2.4.0-bin-hadoop2.7/bin/
- SPARKLING-WATER_HOME: /usr/lib/sparklingwater/sparkling-water-2.3.11/bin
- JUPYTER_HOME: /opt/anaconda3/bin/
- RSTUDIO_HOME:/opt/rstudio/
- SHINYSERVER_HOME:/opt/shiny-server/

### Systemctl service names and commands:  
sudo systemctl status  jupyterhub( start, stop)
sudo systemctl status spark-master (start, stop)
sudo systemctl status spark-slave (start, stop)
sudo systemctl status  rstudioserver(start, stop)
sudo systemctl status  shinyserver(start, stop)

### OS: 
Centos7. Works with both Bluedata Centos and RHEL hosts

## Testcases:

[Spark240_testcases](https://github.com/bluedatainc/solutions/blob/master/AppImage_Testcases/Spark240/2.6/spark240-smoketests.pdf)

## Prerequisites:

1. The user should have prior experience working with the App.
2. Prior Knowledge working with EPIC.
3. Basic understanding of docker, python/scala/Java for running testcases.

## Release notes:

[Spark_releaseNotes](http://docs.bluedata.com/37_epic-37-release-notes$operationspark)

