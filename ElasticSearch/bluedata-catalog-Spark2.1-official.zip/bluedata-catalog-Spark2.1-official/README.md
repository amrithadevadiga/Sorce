# Spark 2.1.0 with Hadoop 2.7

Following are the modification with the exact versions :
* Spark : v2.1.0
* Hadoop : v2.7
* Zeppelin : v0.8.0
* CentOS 7

Jira number : Zymr-63
