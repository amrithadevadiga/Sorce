## Creating orphan git branches

1. git checkout —orphan centos6-official
2. git rm --cached -r .    #3
3. Remove unwanted code
4. Add your app specific code (no need for a separate directory)
5. Commit  your code
6. push the branch to remote
7. add a tag with the latest version. To avoid conflicts the tag should include the branch name.
