# Overview

In this image, the user can access Elasticsearch, Logstash, and Kibana

## What is {name}?

"ELK" is the acronym for three open source projects: Elasticsearch, Logstash, and Kibana. 
Elasticsearch is a search and analytics engine. 
Logstash is a server side data processing pipeline that ingests data from multiple sources simultaneously, transforms it, and then sends it to a "stash" like Elasticsearch. 
Kibana lets users visualize data with charts and graphs in Elasticsearch.

The Elastic Stack is the next evolution of the ELK Stack.

For more details about ELK, refer to this link:
[ELK_doc](https://www.elastic.co/what-is/elk-stack)
[ELK_docker_doc](https://elk-docker.readthedocs.io/)
[ELK_guide](https://www.elastic.co/guide/en/cloud/current/ec-release-notes-2019-03-12.html)


# Details:
## Application Image Details:

### AppName: 
{name}
### DistroId:
{distroid}
### Version: 
{version}

### Cluster Type: 
ElasticSearch

### Software Included: 
Kibana - 6.6.2, 
elasticsearch-6.6.2
logstash-6.6.2
php-5.3.3
Python 2.7.5 

### Kibana Access:   
Kibana GUI Access  - Go to ELK cluster in BlueData GUI then click on Kibana link 
                     Add sample data to kibana , 
                     Discover sample datasheets, 
		             visualize the sample datasheet,
		             Test the dashboard for sample datasheet. 
					 
### Elasticsearch Access: 
elasticsearch GUI Access  - Go to ELK cluster of BD lab GUI then click on elasticsearch link
					
Kibana_HOME:/usr/share/kibana/
Logstash_HOME:/usr/share/logstash/
Elasticsearch_HOME:/usr/share/elasticsearch/


### Systemctl service names and commands:  

sudo systemctl status  elasticsearch( start, stop)
sudo systemctl status kibana (start, stop)
sudo systemctl status logstash (start, stop)

### OS: 
Centos7. Works with both Bluedata Centos and RHEL hosts

## Testcases:

[ELK662_testcases](https://github.com/bluedatainc/solutions/blob/master/AppImage_Testcases/ELKStack662/2.0/elkstack662-smoketests.pdf)

## Prerequisites:

The user should have prior experience working with the App.
Prior Knowledge working with EPIC.
Basic understanding of docker, python/scala/Java and ELK for running testcases.

## Release notes:

None
