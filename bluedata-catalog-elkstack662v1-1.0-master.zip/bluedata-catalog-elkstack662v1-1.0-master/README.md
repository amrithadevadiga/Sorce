ELK Stack 6.6.2 v1:

 List of changes/features:

>> This image consists of ElasticSearch, Kibana and Logstash services. Master node cardinality restricted to 1.

 EPIC versions this bin file is intended for:

>> 4.0 & later

 Jobs and/or action scripts to test the image:

>> Yet to update the smoke tests
>> Apart from Epic test scenarios, test the actions below
	>> 1. Scale up & down
	>> 2. Pumping Data through ELK
	>> 3. Inserting Data & Retrieving Data through postman

 RELEASE NOTES:

>> None 
