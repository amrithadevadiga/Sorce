# CentOS 7 catalog entry.
# Install scipy
