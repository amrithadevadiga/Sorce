/opt/hdf/nifi-1.1.0.2.1.2.0-10/bin/nifi.sh start
pgrep -f 'nifi' > /var/run/HDF-master.pid
