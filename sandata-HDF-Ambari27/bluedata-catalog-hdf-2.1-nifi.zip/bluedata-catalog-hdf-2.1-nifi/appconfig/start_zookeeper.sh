/opt/zookeeper-3.4.6/bin/zkServer.sh start
pgrep -f 'zookeeper' > /var/run/Zookeeper-service.pid
