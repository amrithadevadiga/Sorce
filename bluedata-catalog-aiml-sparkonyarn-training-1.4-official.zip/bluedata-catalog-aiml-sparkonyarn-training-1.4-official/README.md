## Creating orphan git branches

1. git checkout --orphan APPNAME-master
2. git rm --cached -r .    #3
3. Remove unwanted code
4. Add your app specific code (no need for a separate directory)
5. Commit  your code
6. push the branch to remote
7. Review and merge the pull request
7. Add a tag named APPNAME-VERSION-official to mark that release.
