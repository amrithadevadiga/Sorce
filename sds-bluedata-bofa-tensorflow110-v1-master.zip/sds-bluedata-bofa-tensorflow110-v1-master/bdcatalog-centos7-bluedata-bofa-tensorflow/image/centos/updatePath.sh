#!/bin/bash

export PATH=$PATH:/opt/anaconda3/bin/
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-9.0/lib64:/usr/local/cuda-9.0/extras/CUPTI/lib64
#export CUDA_HOME=/usr/local/cuda-9.0/
#export PATH=$PATH:/usr/lib64/openmpi-2.1.5/bin
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib64/openmpi-2.1.5/lib/
