source /etc/profile.d/updatePath.sh
source activate tensorflow
python /opt/test_model.py
