/usr/lib/rstudio-server/bin/rserver
pgrep "rserver" > /var/run/rstudioserver.pid
