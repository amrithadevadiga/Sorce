#!/bin/bash

export PATH=$PATH:/opt/anaconda3/bin/
